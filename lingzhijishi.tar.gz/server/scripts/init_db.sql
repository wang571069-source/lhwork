-- 灵职集市数据库结构
-- LingHuoZhi Saas Freelance Marketplace

CREATE DATABASE IF NOT EXISTS lingzhijishi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lingzhijishi;

-- 用户表
CREATE TABLE IF NOT EXISTS users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    phone VARCHAR(20) UNIQUE NOT NULL COMMENT '手机号',
    password VARCHAR(255) NOT NULL COMMENT '密码(加密)',
    nickname VARCHAR(50) COMMENT '昵称',
    avatar VARCHAR(500) COMMENT '头像URL',
    user_type ENUM('employer', 'provider', 'both') DEFAULT 'both' COMMENT '用户类型:雇主/服务商/两者',
    email VARCHAR(100) COMMENT '邮箱',
    real_name VARCHAR(50) COMMENT '真实姓名',
    id_card VARCHAR(20) COMMENT '身份证号',
    id_card_front VARCHAR(500) COMMENT '身份证正面照',
    id_card_back VARCHAR(500) COMMENT '身份证背面照',
    status ENUM('active', 'disabled', 'banned', 'pending_verify') DEFAULT 'active' COMMENT '账号状态',
    is_identity_verified TINYINT(1) DEFAULT 0 COMMENT '身份认证',
    is_skill_verified TINYINT(1) DEFAULT 0 COMMENT '技能认证',
    provider_status ENUM('none', 'pending', 'approved', 'rejected') DEFAULT 'none' COMMENT '服务商申请状态',
    bio TEXT COMMENT '个人简介',
    skills JSON COMMENT '技能标签',
    hourly_rate DECIMAL(10,2) COMMENT '时薪',
    rating DECIMAL(3,2) DEFAULT 5.00 COMMENT '评分',
    total_earnings DECIMAL(15,2) DEFAULT 0 COMMENT '总收入',
    total_spent DECIMAL(15,2) DEFAULT 0 COMMENT '总支出',
    completed_orders INT DEFAULT 0 COMMENT '完成订单数',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login_at TIMESTAMP NULL,
    INDEX idx_phone (phone),
    INDEX idx_user_type (user_type),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 分类表
CREATE TABLE IF NOT EXISTS categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL COMMENT '分类名称',
    icon VARCHAR(100) COMMENT '图标',
    parent_id INT DEFAULT 0 COMMENT '父分类ID',
    sort_order INT DEFAULT 0 COMMENT '排序',
    status TINYINT(1) DEFAULT 1 COMMENT '状态:0禁用1启用',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_parent (parent_id),
    INDEX idx_sort (sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='服务分类表';

-- 服务表( freelancers发布的服务)
CREATE TABLE IF NOT EXISTS services (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL COMMENT '服务商ID',
    category_id INT COMMENT '分类ID',
    title VARCHAR(200) NOT NULL COMMENT '服务标题',
    description TEXT COMMENT '服务描述',
    images JSON COMMENT '服务图片列表',
    price_min DECIMAL(10,2) COMMENT '最低价格',
    price_max DECIMAL(10,2) COMMENT '最高价格',
    delivery_days INT DEFAULT 7 COMMENT '交付天数',
    revision_count INT DEFAULT 1 COMMENT '修改次数',
    rating DECIMAL(3,2) DEFAULT 5.00 COMMENT '评分',
    review_count INT DEFAULT 0 COMMENT '评价数',
    order_count INT DEFAULT 0 COMMENT '订单数',
    is_top TINYINT(1) DEFAULT 0 COMMENT '是否置顶',
    is_featured TINYINT(1) DEFAULT 0 COMMENT '是否精选',
    status ENUM('active', 'draft', 'paused', 'deleted') DEFAULT 'draft' COMMENT '状态',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_category (category_id),
    INDEX idx_status (status),
    INDEX idx_price (price_min, price_max),
    FULLTEXT idx_title (title, description)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='服务表';

-- 服务套餐表
CREATE TABLE IF NOT EXISTS service_packages (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_id BIGINT NOT NULL COMMENT '服务ID',
    name VARCHAR(100) NOT NULL COMMENT '套餐名称',
    description TEXT COMMENT '套餐描述',
    price DECIMAL(10,2) NOT NULL COMMENT '价格',
    delivery_days INT DEFAULT 7 COMMENT '交付天数',
    revision_count INT DEFAULT 1 COMMENT '修改次数',
    features JSON COMMENT '功能列表',
    sort_order INT DEFAULT 0 COMMENT '排序',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_service (service_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='服务套餐表';

-- 项目表(雇主发布的项目需求)
CREATE TABLE IF NOT EXISTS projects (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL COMMENT '雇主ID',
    category_id INT COMMENT '分类ID',
    title VARCHAR(200) NOT NULL COMMENT '项目标题',
    description TEXT COMMENT '项目描述',
    budget_min DECIMAL(10,2) COMMENT '预算最低',
    budget_max DECIMAL(10,2) COMMENT '预算最高',
    deadline DATETIME COMMENT '截止日期',
    status ENUM('open', 'in_progress', 'completed', 'cancelled', 'closed') DEFAULT 'open' COMMENT '状态',
    skills JSON COMMENT '技能要求',
    attachment_urls JSON COMMENT '附件URL',
    proposals_count INT DEFAULT 0 COMMENT '收到的投标数',
    assigned_provider_id BIGINT COMMENT '中标的服务商ID',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_category (category_id),
    INDEX idx_status (status),
    FULLTEXT idx_title (title, description)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='项目表';

-- 投标表
CREATE TABLE IF NOT EXISTS proposals (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    project_id BIGINT NOT NULL COMMENT '项目ID',
    user_id BIGINT NOT NULL COMMENT '服务商ID',
    price DECIMAL(10,2) NOT NULL COMMENT '报价',
    duration_days INT NOT NULL COMMENT '工期天数',
    cover_letter TEXT COMMENT '投标信',
    status ENUM('pending', 'accepted', 'rejected', 'withdrawn') DEFAULT 'pending' COMMENT '状态',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_project (project_id),
    INDEX idx_user (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='投标表';

-- 订单表
CREATE TABLE IF NOT EXISTS orders (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_no VARCHAR(50) UNIQUE NOT NULL COMMENT '订单号',
    buyer_id BIGINT NOT NULL COMMENT '买家ID',
    seller_id BIGINT NOT NULL COMMENT '卖家ID',
    type ENUM('service', 'project') NOT NULL COMMENT '订单类型:服务/项目',
    source_id BIGINT NOT NULL COMMENT '来源ID(服务ID或项目ID)',
    package_id BIGINT COMMENT '套餐ID(服务订单)',
    title VARCHAR(200) NOT NULL COMMENT '订单标题',
    description TEXT COMMENT '需求描述',
    amount DECIMAL(10,2) NOT NULL COMMENT '订单金额',
    platform_fee DECIMAL(10,2) DEFAULT 0 COMMENT '平台费',
    actual_amount DECIMAL(10,2) NOT NULL COMMENT '实际支付金额',
    status ENUM('pending_payment', 'paid', 'in_progress', 'submitted', 'completed', 'cancelled', 'refunded', 'disputed') DEFAULT 'pending_payment' COMMENT '状态',
    payment_method VARCHAR(20) COMMENT '支付方式',
    payment_time DATETIME COMMENT '支付时间',
    submit_time DATETIME COMMENT '提交时间',
    complete_time DATETIME COMMENT '完成时间',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_buyer (buyer_id),
    INDEX idx_seller (seller_id),
    INDEX idx_status (status),
    INDEX idx_order_no (order_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- 钱包表
CREATE TABLE IF NOT EXISTS wallets (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT UNIQUE NOT NULL COMMENT '用户ID',
    balance DECIMAL(15,2) DEFAULT 0 COMMENT '余额',
    frozen_amount DECIMAL(15,2) DEFAULT 0 COMMENT '冻结金额',
    total_earnings DECIMAL(15,2) DEFAULT 0 COMMENT '累计收入',
    total_withdrawn DECIMAL(15,2) DEFAULT 0 COMMENT '累计提现',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='钱包表';

-- 钱包流水表
CREATE TABLE IF NOT EXISTS wallet_transactions (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    wallet_id BIGINT NOT NULL COMMENT '钱包ID',
    type ENUM('income', 'expense', 'frozen', 'unfrozen', 'withdraw') NOT NULL COMMENT '类型',
    amount DECIMAL(10,2) NOT NULL COMMENT '金额',
    balance_before DECIMAL(15,2) COMMENT '变动前余额',
    balance_after DECIMAL(15,2) COMMENT '变动后余额',
    source ENUM('order_payment', 'order_complete', 'order_refund', 'withdraw', 'platform_subsidy', 'penalty') COMMENT '来源',
    source_id BIGINT COMMENT '来源ID',
    description VARCHAR(500) COMMENT '描述',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_wallet (wallet_id),
    INDEX idx_type (type),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='钱包流水表';

-- 评价表
CREATE TABLE IF NOT EXISTS reviews (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT UNIQUE NOT NULL COMMENT '订单ID',
    reviewer_id BIGINT NOT NULL COMMENT '评价者ID',
    reviewee_id BIGINT NOT NULL COMMENT '被评价者ID',
    rating TINYINT NOT NULL COMMENT '评分1-5',
    rating_quality TINYINT COMMENT '质量评分',
    rating_communication TINYINT COMMENT '沟通评分',
    rating_delivery TINYINT COMMENT '交付评分',
    comment TEXT COMMENT '评价内容',
    reply TEXT COMMENT '回复内容',
    reply_time DATETIME COMMENT '回复时间',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_order (order_id),
    INDEX idx_reviewer (reviewer_id),
    INDEX idx_reviewee (reviewee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评价表';

-- 提现表
CREATE TABLE IF NOT EXISTS withdrawals (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL COMMENT '用户ID',
    wallet_id BIGINT NOT NULL COMMENT '钱包ID',
    amount DECIMAL(10,2) NOT NULL COMMENT '提现金额',
    fee DECIMAL(10,2) DEFAULT 0 COMMENT '手续费',
    actual_amount DECIMAL(10,2) NOT NULL COMMENT '实际到账',
    bank_name VARCHAR(50) COMMENT '银行名称',
    bank_account VARCHAR(50) COMMENT '银行账号',
    bank_holder VARCHAR(50) COMMENT '持卡人姓名',
    status ENUM('pending', 'approved', 'rejected', 'processing', 'completed', 'failed') DEFAULT 'pending' COMMENT '状态',
    reject_reason VARCHAR(200) COMMENT '拒绝原因',
    process_time DATETIME COMMENT '处理时间',
    complete_time DATETIME COMMENT '完成时间',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='提现表';

-- 退款表
CREATE TABLE IF NOT EXISTS refunds (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT UNIQUE NOT NULL COMMENT '订单ID',
    user_id BIGINT NOT NULL COMMENT '申请人ID',
    amount DECIMAL(10,2) NOT NULL COMMENT '退款金额',
    reason TEXT NOT NULL COMMENT '退款原因',
    evidence_urls JSON COMMENT '证据图片',
    status ENUM('pending', 'approved', 'rejected', 'refunded') DEFAULT 'pending' COMMENT '状态',
    admin_reply TEXT COMMENT '管理员回复',
    process_time DATETIME COMMENT '处理时间',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_order (order_id),
    INDEX idx_user (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='退款表';

-- 消息表
CREATE TABLE IF NOT EXISTS messages (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    sender_id BIGINT NOT NULL COMMENT '发送者ID',
    receiver_id BIGINT NOT NULL COMMENT '接收者ID',
    order_id BIGINT COMMENT '关联订单ID',
    content TEXT NOT NULL COMMENT '消息内容',
    type ENUM('text', 'image', 'file', 'system') DEFAULT 'text' COMMENT '类型',
    is_read TINYINT(1) DEFAULT 0 COMMENT '是否已读',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sender (sender_id),
    INDEX idx_receiver (receiver_id),
    INDEX idx_order (order_id),
    INDEX idx_unread (receiver_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息表';

-- 通知表
CREATE TABLE IF NOT EXISTS notifications (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL COMMENT '用户ID',
    type VARCHAR(50) NOT NULL COMMENT '通知类型',
    title VARCHAR(200) NOT NULL COMMENT '标题',
    content TEXT COMMENT '内容',
    data JSON COMMENT '扩展数据',
    is_read TINYINT(1) DEFAULT 0 COMMENT '是否已读',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_unread (user_id, is_read),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='通知表';

-- 系统配置表
CREATE TABLE IF NOT EXISTS system_config (
    id INT PRIMARY KEY AUTO_INCREMENT,
    config_key VARCHAR(100) UNIQUE NOT NULL COMMENT '配置键',
    config_value TEXT COMMENT '配置值',
    description VARCHAR(200) COMMENT '描述',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统配置表';

-- 插入默认分类
INSERT INTO categories (name, icon, parent_id, sort_order) VALUES
('Logo设计', 'design', 0, 1),
('网站开发', 'code', 0, 2),
('APP开发', 'mobile', 0, 3),
('视频剪辑', 'video', 0, 4),
('文案写作', 'edit', 0, 5),
('营销推广', 'campaign', 0, 6),
('翻译服务', 'translate', 0, 7),
('音乐音频', 'music', 0, 8),
('商务咨询', 'business', 0, 9),
('其他服务', 'more', 0, 10);

-- 插入系统配置
INSERT INTO system_config (config_key, config_value, description) VALUES
('platform_fee_percent', '15', '平台抽成百分比'),
('min_withdraw_amount', '100', '最低提现金额'),
('withdraw_fee_percent', '1', '提现手续费百分比'),
('max_upload_size', '10485760', '最大上传文件大小(字节)'),
('site_name', '灵职集市', '网站名称'),
('site_logo', '', '网站Logo'),
('contact_email', 'support@lingzhijishi.com', '联系邮箱'),
('contact_phone', '400-888-8888', '联系电话');

-- 初始化用户的钱包
INSERT INTO wallets (user_id) SELECT id FROM users;
