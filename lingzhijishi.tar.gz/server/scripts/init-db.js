/**
 * 灵职集市数据库初始化脚本
 * 初始化数据库、表结构、默认数据和测试数据
 */

const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// 数据库配置
const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER || 'debian-sys-maint',
    password: process.env.DB_PASSWORD || '6PUYpZMjVdj5Mpzm',
    charset: 'utf8mb4'
};

const dbName = 'lingzhijishi';

// 默认分类
const defaultCategories = [
    { name: '设计服务', icon: 'design', sort_order: 1 },
    { name: '开发服务', icon: 'code', sort_order: 2 },
    { name: '视频服务', icon: 'video', sort_order: 3 },
    { name: '文案写作', icon: 'edit', sort_order: 4 },
    { name: '翻译服务', icon: 'translate', sort_order: 5 },
    { name: '营销推广', icon: 'campaign', sort_order: 6 },
    { name: '商务咨询', icon: 'business', sort_order: 7 },
    { name: '其他服务', icon: 'more', sort_order: 8 }
];

// MD5哈希函数
function md5(str) {
    return crypto.createHash('md5').update(str).digest('hex');
}

// 创建密码哈希
function hashPassword(password) {
    return md5(password);
}

async function initDatabase() {
    let connection;
    
    try {
        console.log('=== 灵职集市数据库初始化开始 ===\n');
        
        // 1. 连接MySQL服务器（不指定数据库）
        console.log('1. 连接MySQL服务器...');
        connection = await mysql.createConnection({
            host: dbConfig.host,
            port: dbConfig.port,
            user: dbConfig.user,
            password: dbConfig.password,
            charset: dbConfig.charset
        });
        console.log('   连接成功!\n');
        
        // 2. 创建数据库
        console.log('2. 创建数据库...');
        await connection.query(`CREATE DATABASE IF NOT EXISTS ${dbName} CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
        console.log(`   数据库 ${dbName} 创建成功!\n`);
        
        // 3. 使用数据库
        await connection.query(`USE ${dbName}`);
        console.log('3. 使用数据库...\n');
        
        // 4. 创建表结构
        console.log('4. 创建表结构...');
        
        // 用户表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS users (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                username VARCHAR(50) UNIQUE NOT NULL COMMENT '用户名',
                phone VARCHAR(20) UNIQUE NOT NULL COMMENT '手机号',
                password_hash VARCHAR(255) NOT NULL COMMENT '密码哈希',
                nickname VARCHAR(50) COMMENT '昵称',
                avatar VARCHAR(500) COMMENT '头像URL',
                role ENUM('employer', 'freelancer', 'admin') DEFAULT 'freelancer' COMMENT '角色',
                email VARCHAR(100) COMMENT '邮箱',
                status ENUM('active', 'disabled', 'banned') DEFAULT 'active' COMMENT '状态',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                INDEX idx_phone (phone),
                INDEX idx_username (username),
                INDEX idx_role (role),
                INDEX idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表'
        `);
        console.log('   - users 表创建成功');
        
        // 用户资料表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS user_profiles (
                user_id BIGINT PRIMARY KEY COMMENT '用户ID',
                real_name VARCHAR(50) COMMENT '真实姓名',
                id_card VARCHAR(20) COMMENT '身份证号',
                id_card_front VARCHAR(500) COMMENT '身份证正面照',
                id_card_back VARCHAR(500) COMMENT '身份证背面照',
                gender ENUM('male', 'female', 'unknown') DEFAULT 'unknown' COMMENT '性别',
                birthday DATE COMMENT '生日',
                province VARCHAR(50) COMMENT '省份',
                city VARCHAR(50) COMMENT '城市',
                bio TEXT COMMENT '个人简介',
                skills JSON COMMENT '技能标签列表',
                rating DECIMAL(3,2) DEFAULT 5.00 COMMENT '评分',
                rating_count INT DEFAULT 0 COMMENT '评价次数',
                total_earnings DECIMAL(15,2) DEFAULT 0 COMMENT '累计收入',
                verified_at TIMESTAMP NULL COMMENT '认证时间',
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                INDEX idx_province_city (province, city)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户资料表'
        `);
        console.log('   - user_profiles 表创建成功');
        
        // 分类表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS categories (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(50) NOT NULL COMMENT '分类名称',
                icon VARCHAR(100) COMMENT '图标',
                parent_id INT DEFAULT 0 COMMENT '父分类ID',
                sort_order INT DEFAULT 0 COMMENT '排序',
                status TINYINT(1) DEFAULT 1 COMMENT '状态:0禁用1启用',
                INDEX idx_parent (parent_id),
                INDEX idx_sort (sort_order)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='分类表'
        `);
        console.log('   - categories 表创建成功');
        
        // 项目表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS projects (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                employer_id BIGINT NOT NULL COMMENT '雇主ID',
                title VARCHAR(200) NOT NULL COMMENT '项目标题',
                description TEXT COMMENT '项目描述',
                category_id INT COMMENT '分类ID',
                budget_min DECIMAL(10,2) COMMENT '预算最低',
                budget_max DECIMAL(10,2) COMMENT '预算最高',
                timeline INT COMMENT '工期(天)',
                status ENUM('open', 'in_progress', 'completed', 'closed', 'cancelled') DEFAULT 'open' COMMENT '状态',
                view_count INT DEFAULT 0 COMMENT '浏览次数',
                proposal_count INT DEFAULT 0 COMMENT '投标数',
                deadline DATETIME COMMENT '截止日期',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (employer_id) REFERENCES users(id),
                FOREIGN KEY (category_id) REFERENCES categories(id),
                INDEX idx_employer (employer_id),
                INDEX idx_category (category_id),
                INDEX idx_status (status),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='项目表'
        `);
        console.log('   - projects 表创建成功');
        
        // 项目投标表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS project_proposals (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                project_id BIGINT NOT NULL COMMENT '项目ID',
                freelancer_id BIGINT NOT NULL COMMENT ' freelancer ID',
                price DECIMAL(10,2) NOT NULL COMMENT '报价',
                proposal_text TEXT COMMENT '投标说明',
                timeline INT COMMENT '工期(天)',
                status ENUM('pending', 'accepted', 'rejected', 'withdrawn') DEFAULT 'pending' COMMENT '状态',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (project_id) REFERENCES projects(id),
                FOREIGN KEY (freelancer_id) REFERENCES users(id),
                INDEX idx_project (project_id),
                INDEX idx_freelancer (freelancer_id),
                INDEX idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='项目投标表'
        `);
        console.log('   - project_proposals 表创建成功');
        
        // 服务表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS services (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                provider_id BIGINT NOT NULL COMMENT '服务商ID',
                title VARCHAR(200) NOT NULL COMMENT '服务标题',
                description TEXT COMMENT '服务描述',
                category_id INT COMMENT '分类ID',
                price_min DECIMAL(10,2) COMMENT '最低价格',
                price_max DECIMAL(10,2) COMMENT '最高价格',
                images JSON COMMENT '服务图片列表',
                tags JSON COMMENT '标签列表',
                rating DECIMAL(3,2) DEFAULT 5.00 COMMENT '评分',
                rating_count INT DEFAULT 0 COMMENT '评价数',
                sales_count INT DEFAULT 0 COMMENT '销量',
                status ENUM('active', 'draft', 'paused', 'deleted') DEFAULT 'draft' COMMENT '状态',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (provider_id) REFERENCES users(id),
                FOREIGN KEY (category_id) REFERENCES categories(id),
                INDEX idx_provider (provider_id),
                INDEX idx_category (category_id),
                INDEX idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='服务表'
        `);
        console.log('   - services 表创建成功');
        
        // 服务套餐表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS service_packages (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                service_id BIGINT NOT NULL COMMENT '服务ID',
                name VARCHAR(100) NOT NULL COMMENT '套餐名称',
                description TEXT COMMENT '套餐描述',
                price DECIMAL(10,2) NOT NULL COMMENT '价格',
                delivery_days INT DEFAULT 7 COMMENT '交付天数',
                revision_count INT DEFAULT 1 COMMENT '修改次数',
                FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
                INDEX idx_service (service_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='服务套餐表'
        `);
        console.log('   - service_packages 表创建成功');
        
        // 订单表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS orders (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                project_id BIGINT COMMENT '项目ID',
                proposal_id BIGINT COMMENT '投标ID',
                employer_id BIGINT NOT NULL COMMENT '雇主ID',
                provider_id BIGINT NOT NULL COMMENT '服务商ID',
                amount DECIMAL(10,2) NOT NULL COMMENT '订单金额',
                platform_fee DECIMAL(10,2) DEFAULT 0 COMMENT '平台费',
                provider_earning DECIMAL(10,2) DEFAULT 0 COMMENT '服务商收入',
                status ENUM('pending', 'paid', 'in_progress', 'completed', 'cancelled', 'refunded') DEFAULT 'pending' COMMENT '状态',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                paid_at TIMESTAMP NULL COMMENT '支付时间',
                completed_at TIMESTAMP NULL COMMENT '完成时间',
                FOREIGN KEY (project_id) REFERENCES projects(id),
                FOREIGN KEY (proposal_id) REFERENCES project_proposals(id),
                FOREIGN KEY (employer_id) REFERENCES users(id),
                FOREIGN KEY (provider_id) REFERENCES users(id),
                INDEX idx_employer (employer_id),
                INDEX idx_provider (provider_id),
                INDEX idx_status (status),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表'
        `);
        console.log('   - orders 表创建成功');
        
        // 钱包表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS wallets (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                user_id BIGINT UNIQUE NOT NULL COMMENT '用户ID',
                balance DECIMAL(15,2) DEFAULT 0 COMMENT '余额',
                frozen_balance DECIMAL(15,2) DEFAULT 0 COMMENT '冻结金额',
                total_earnings DECIMAL(15,2) DEFAULT 0 COMMENT '累计收入',
                total_withdrawn DECIMAL(15,2) DEFAULT 0 COMMENT '累计提现',
                FOREIGN KEY (user_id) REFERENCES users(id),
                INDEX idx_user (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='钱包表'
        `);
        console.log('   - wallets 表创建成功');
        
        // 钱包流水表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS wallet_transactions (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                wallet_id BIGINT NOT NULL COMMENT '钱包ID',
                type ENUM('income', 'expense', 'withdraw', 'refund', 'frozen', 'unfrozen') NOT NULL COMMENT '类型',
                amount DECIMAL(10,2) NOT NULL COMMENT '金额',
                balance_before DECIMAL(15,2) COMMENT '变动前余额',
                balance_after DECIMAL(15,2) COMMENT '变动后余额',
                description VARCHAR(500) COMMENT '描述',
                order_id BIGINT COMMENT '关联订单ID',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (wallet_id) REFERENCES wallets(id),
                INDEX idx_wallet (wallet_id),
                INDEX idx_type (type),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='钱包流水表'
        `);
        console.log('   - wallet_transactions 表创建成功');
        
        // 提现表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS withdrawals (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                user_id BIGINT NOT NULL COMMENT '用户ID',
                amount DECIMAL(10,2) NOT NULL COMMENT '提现金额',
                bank_name VARCHAR(100) COMMENT '银行名称',
                bank_card VARCHAR(50) COMMENT '银行卡号',
                status ENUM('pending', 'approved', 'rejected', 'completed') DEFAULT 'pending' COMMENT '状态',
                processed_at TIMESTAMP NULL COMMENT '处理时间',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id),
                INDEX idx_user (user_id),
                INDEX idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='提现表'
        `);
        console.log('   - withdrawals 表创建成功');
        
        // 消息表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS messages (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                from_user_id BIGINT NOT NULL COMMENT '发送者ID',
                to_user_id BIGINT NOT NULL COMMENT '接收者ID',
                project_id BIGINT COMMENT '关联项目ID',
                content TEXT NOT NULL COMMENT '消息内容',
                read_at TIMESTAMP NULL COMMENT '阅读时间',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (from_user_id) REFERENCES users(id),
                FOREIGN KEY (to_user_id) REFERENCES users(id),
                FOREIGN KEY (project_id) REFERENCES projects(id),
                INDEX idx_from_user (from_user_id),
                INDEX idx_to_user (to_user_id),
                INDEX idx_project (project_id),
                INDEX idx_unread (to_user_id, read_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息表'
        `);
        console.log('   - messages 表创建成功');
        
        // 通知表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS notifications (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                user_id BIGINT NOT NULL COMMENT '用户ID',
                type VARCHAR(50) NOT NULL COMMENT '通知类型',
                title VARCHAR(200) NOT NULL COMMENT '标题',
                content TEXT COMMENT '内容',
                read_at TIMESTAMP NULL COMMENT '阅读时间',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id),
                INDEX idx_user (user_id),
                INDEX idx_unread (user_id, read_at),
                INDEX idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='通知表'
        `);
        console.log('   - notifications 表创建成功');
        
        // 评价表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS reviews (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                order_id BIGINT NOT NULL COMMENT '订单ID',
                project_id BIGINT COMMENT '项目ID',
                reviewer_id BIGINT NOT NULL COMMENT '评价者ID',
                reviewee_id BIGINT NOT NULL COMMENT '被评价者ID',
                rating TINYINT NOT NULL COMMENT '评分1-5',
                content TEXT COMMENT '评价内容',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (order_id) REFERENCES orders(id),
                FOREIGN KEY (project_id) REFERENCES projects(id),
                FOREIGN KEY (reviewer_id) REFERENCES users(id),
                FOREIGN KEY (reviewee_id) REFERENCES users(id),
                INDEX idx_order (order_id),
                INDEX idx_project (project_id),
                INDEX idx_reviewer (reviewer_id),
                INDEX idx_reviewee (reviewee_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评价表'
        `);
        console.log('   - reviews 表创建成功');
        
        // 管理员表
        await connection.query(`
            CREATE TABLE IF NOT EXISTS admin_users (
                id BIGINT PRIMARY KEY AUTO_INCREMENT,
                username VARCHAR(50) UNIQUE NOT NULL COMMENT '用户名',
                password_hash VARCHAR(255) NOT NULL COMMENT '密码哈希',
                nickname VARCHAR(50) COMMENT '昵称',
                role VARCHAR(20) DEFAULT 'admin' COMMENT '角色',
                status ENUM('active', 'disabled') DEFAULT 'active' COMMENT '状态',
                INDEX idx_username (username)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员表'
        `);
        console.log('   - admin_users 表创建成功');
        
        console.log('\n   所有表创建完成!\n');
        
        // 5. 插入默认分类
        console.log('5. 插入默认分类...');
        for (const cat of defaultCategories) {
            await connection.query(
                'INSERT INTO categories (name, icon, parent_id, sort_order) VALUES (?, ?, 0, ?)',
                [cat.name, cat.icon, cat.sort_order]
            );
        }
        console.log(`   ${defaultCategories.length} 个分类插入成功!\n`);
        
        // 6. 插入管理员账号
        console.log('6. 插入管理员账号...');
        const adminPassword = hashPassword('admin123');
        await connection.query(
            'INSERT INTO admin_users (username, password_hash, nickname, role) VALUES (?, ?, ?, ?)',
            ['admin', adminPassword, '系统管理员', 'super_admin']
        );
        console.log('   管理员账号创建成功 (admin/admin123)\n');
        
        // 7. 插入测试数据
        console.log('7. 插入测试数据...');
        
        // 测试用户 - 雇主
        await connection.query(`
            INSERT INTO users (username, phone, password_hash, nickname, role, email) VALUES
            ('employer1', '13800138001', ?, '张三', 'employer', 'zhangsan@example.com'),
            ('freelancer1', '13800138002', ?, '李四', 'freelancer', 'lisi@example.com'),
            ('freelancer2', '13800138003', ?, '王五', 'freelancer', 'wangwu@example.com')
        `, [hashPassword('test123'), hashPassword('test123'), hashPassword('test123')]);
        console.log('   测试用户创建成功');
        
        // 用户资料
        await connection.query(`
            INSERT INTO user_profiles (user_id, real_name, gender, province, city, bio, skills, rating, rating_count) VALUES
            (1, '张三', 'male', '北京', '北京市', '我是需求方', '["项目管理"]', 5.00, 0),
            (2, '李四', 'male', '上海', '上海市', '专业设计师', '["UI设计", "Logo设计", "海报设计"]', 4.80, 10),
            (3, '王五', 'male', '广东', '深圳市', '全栈开发者', '["前端开发", "后端开发", "移动端开发"]', 4.90, 15)
        `);
        console.log('   用户资料创建成功');
        
        // 钱包
        await connection.query(`
            INSERT INTO wallets (user_id, balance, frozen_balance, total_earnings) VALUES
            (1, 10000.00, 0, 0),
            (2, 5000.00, 0, 15000.00),
            (3, 8000.00, 0, 20000.00)
        `);
        console.log('   钱包记录创建成功');
        
        // 测试项目
        await connection.query(`
            INSERT INTO projects (employer_id, title, description, category_id, budget_min, budget_max, timeline, status, view_count, proposal_count, deadline) VALUES
            (1, '需要设计一个公司Logo', '需要简约大气的公司Logo，适合科技公司使用', 1, 1000.00, 3000.00, 7, 'open', 100, 5, DATE_ADD(NOW(), INTERVAL 30 DAY)),
            (1, '网站开发需求', '需要开发一个企业官网，包含后台管理系统', 2, 5000.00, 15000.00, 30, 'open', 200, 8, DATE_ADD(NOW(), INTERVAL 60 DAY))
        `);
        console.log('   测试项目创建成功');
        
        // 测试服务
        await connection.query(`
            INSERT INTO services (provider_id, title, description, category_id, price_min, price_max, images, tags, rating, rating_count, sales_count, status) VALUES
            (2, '专业Logo设计服务', '提供高品质Logo设计，包含3次修改', 1, 500.00, 2000.00, '["/uploads/logo1.jpg", "/uploads/logo2.jpg"]', '["Logo", "VI设计", "品牌设计"]', 4.80, 10, 50, 'active'),
            (3, '全栈网站开发', '专业网站开发，前端后端都能做', 2, 3000.00, 10000.00, '["/uploads/web1.jpg"]', '["网站开发", "前端", "后端", "数据库"]', 4.90, 15, 30, 'active')
        `);
        console.log('   测试服务创建成功');
        
        // 服务套餐
        await connection.query(`
            INSERT INTO service_packages (service_id, name, description, price, delivery_days, revision_count) VALUES
            (1, '基础版', '简单Logo设计，1次修改', 500.00, 3, 1),
            (1, '标准版', 'Logo设计，3次修改，提供源文件', 1200.00, 7, 3),
            (1, '高级版', '完整VI设计，无限修改', 2000.00, 14, 99),
            (2, '基础网站', '单页面展示网站', 3000.00, 14, 2),
            (2, '企业官网', '多页面企业官网', 8000.00, 30, 3)
        `);
        console.log('   服务套餐创建成功');
        
        // 项目投标
        await connection.query(`
            INSERT INTO project_proposals (project_id, freelancer_id, price, proposal_text, timeline, status) VALUES
            (1, 2, 1500.00, '您好，我有丰富的Logo设计经验，可以为您提供专业的设计方案。', 5, 'pending'),
            (1, 3, 2000.00, '我是全栈设计师，可以提供完整的品牌设计方案。', 7, 'pending'),
            (2, 3, 10000.00, '我可以为您开发完整的企业官网，包含后台系统。', 25, 'pending')
        `);
        console.log('   项目投标创建成功');
        
        // 订单
        await connection.query(`
            INSERT INTO orders (project_id, proposal_id, employer_id, provider_id, amount, platform_fee, provider_earning, status, created_at, paid_at) VALUES
            (NULL, NULL, 1, 2, 1200.00, 180.00, 1020.00, 'completed', DATE_SUB(NOW(), INTERVAL 10 DAY), DATE_SUB(NOW(), INTERVAL 10 DAY)),
            (1, 1, 1, 2, 1500.00, 225.00, 1275.00, 'in_progress', DATE_SUB(NOW(), INTERVAL 2 DAY), DATE_SUB(NOW(), INTERVAL 2 DAY))
        `);
        console.log('   订单创建成功');
        
        // 评价
        await connection.query(`
            INSERT INTO reviews (order_id, project_id, reviewer_id, reviewee_id, rating, content) VALUES
            (1, NULL, 1, 2, 5, '设计非常专业，沟通顺畅，强烈推荐!')
        `);
        console.log('   评价创建成功');
        
        // 消息
        await connection.query(`
            INSERT INTO messages (from_user_id, to_user_id, project_id, content) VALUES
            (1, 2, 1, '您好，请问您能接这个Logo设计项目吗？'),
            (2, 1, 1, '您好，我可以接这个项目，请问你对设计风格有什么要求？'),
            (1, 2, 1, '希望简约大气一些，类似科技公司的风格')
        `);
        console.log('   消息创建成功');
        
        // 通知
        await connection.query(`
            INSERT INTO notifications (user_id, type, title, content) VALUES
            (1, 'system', '欢迎使用灵职集市', '欢迎来到灵职集市，祝您使用愉快！'),
            (2, 'proposal', '新投标通知', '您有一个新的项目投标'),
            (1, 'order', '订单完成', '您的订单已完成，请对服务商进行评价')
        `);
        console.log('   通知创建成功');
        
        console.log('\n=== 初始化完成 ===');
        console.log('\n默认数据:');
        console.log('- 8 个服务分类');
        console.log('- 管理员账号: admin / admin123');
        console.log('- 3 个测试用户 (密码都是 test123)');
        console.log('- 2 个测试项目');
        console.log('- 2 个测试服务');
        console.log('- 5 个服务套餐');
        console.log('- 3 个项目投标');
        console.log('- 2 个订单');
        console.log('- 1 个评价');
        console.log('- 3 条消息');
        console.log('- 3 条通知');
        
    } catch (error) {
        console.error('初始化失败:', error.message);
        throw error;
    } finally {
        if (connection) {
            await connection.end();
            console.log('\n数据库连接已关闭');
        }
    }
}

// 运行初始化
initDatabase()
    .then(() => {
        console.log('\n数据库初始化成功!');
        process.exit(0);
    })
    .catch((err) => {
        console.error('数据库初始化失败:', err);
        process.exit(1);
    });
