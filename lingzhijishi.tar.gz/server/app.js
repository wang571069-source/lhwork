const express = require('express');
const path = require('path');
require('dotenv').config();
const { initDatabase } = require('./config/database');

const app = express();

// 初始化数据库
let dbInitialized = false;
let server = null;

initDatabase()
    .then(() => {
        dbInitialized = true;
        console.log('✅ 数据库初始化完成');
        // 数据库就绪后设置中间件并启动
        setupMiddleware();
        startServer();
    })
    .catch(err => {
        console.error('❌ 数据库初始化失败:', err);
        process.exit(1);
    });

function setupMiddleware() {
    app.use(express.json({ limit: '10mb' }));
    app.use(express.urlencoded({ extended: true, limit: '10mb' }));

    // CORS配置
    app.use((req, res, next) => {
        res.header('Access-Control-Allow-Origin', '*');
        res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
        if (req.method === 'OPTIONS') {
            return res.sendStatus(200);
        }
        next();
    });

    // 静态文件
    app.use(express.static(path.join(__dirname, '../frontend')));

    // 路由
    const authRoutes = require('./routes/auth');
    const userRoutes = require('./routes/user');
    const serviceRoutes = require('./routes/service');
    const projectRoutes = require('./routes/project');
    const orderRoutes = require('./routes/order');
    const walletRoutes = require('./routes/wallet');
    const categoryRoutes = require('./routes/category');
    const homeRoutes = require('./routes/home');
    const adminRoutes = require('./routes/admin');
    const messageRoutes = require('./routes/message');
    const notificationRoutes = require('./routes/notification');
    const reviewRoutes = require('./routes/review');

    app.use('/api/auth', authRoutes);
    app.use('/api/user', userRoutes);
    app.use('/api/service', serviceRoutes);
    app.use('/api/project', projectRoutes);
    app.use('/api/order', orderRoutes);
    app.use('/api/wallet', walletRoutes);
    app.use('/api/category', categoryRoutes);
    app.use('/api/home', homeRoutes);
    app.use('/api/admin', adminRoutes);
    app.use('/api/message', messageRoutes);
    app.use('/api/notification', notificationRoutes);
    app.use('/api/review', reviewRoutes);

    // 健康检查
    app.get('/health', (req, res) => {
        res.json({ status: 'ok', service: '灵职集市', time: new Date().toISOString() });
    });

    // 根路径返回前端
    app.get('/', (req, res) => {
        res.sendFile(path.join(__dirname, '../frontend/index.html'));
    });

    // 管理后台
    app.get('/admin', (req, res) => {
        res.sendFile(path.join(__dirname, '../frontend/admin.html'));
    });

    // 404处理
    app.use((req, res) => {
        res.status(404).json({ error: '接口不存在' });
    });

    // 错误处理
    app.use((err, req, res, next) => {
        console.error('服务器错误:', err);
        res.status(500).json({ error: '服务器内部错误' });
    });
}

function startServer() {
    const PORT = process.env.PORT || 3000;
    server = app.listen(PORT, '0.0.0.0', () => {
        console.log(`灵职集市服务已启动，端口: ${PORT}`);
        console.log(`环境: ${process.env.NODE_ENV || 'development'}`);
    });
}

module.exports = app;
