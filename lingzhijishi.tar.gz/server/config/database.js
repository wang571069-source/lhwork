const mysql = require('mysql2/promise');

const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER || 'debian-sys-maint',
    password: process.env.DB_PASSWORD || '6PUYpZMjVdj5Mpzm',
    database: process.env.DB_NAME || 'lingzhijishi',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    charset: 'utf8mb4'
};

let pool = null;

async function initDatabase() {
    // 先连接不带数据库创建数据库
    const tempConnection = await mysql.createConnection({
        host: dbConfig.host,
        port: dbConfig.port,
        user: dbConfig.user,
        password: dbConfig.password,
        charset: 'utf8mb4'
    });

    await tempConnection.query(`CREATE DATABASE IF NOT EXISTS \`${dbConfig.database}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    await tempConnection.end();

    // 创建连接池
    pool = mysql.createPool(dbConfig);

    // 创建表
    await createTables();
    
    console.log('✅ 数据库初始化完成');
    return pool;
}

async function createTables() {
    const queries = [
        `CREATE TABLE IF NOT EXISTS users (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            phone VARCHAR(20) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            nickname VARCHAR(50),
            avatar VARCHAR(500),
            user_type ENUM('employer', 'provider', 'both') DEFAULT 'both',
            email VARCHAR(100),
            real_name VARCHAR(50),
            id_card VARCHAR(20),
            id_card_front VARCHAR(500),
            id_card_back VARCHAR(500),
            status ENUM('active', 'disabled', 'banned', 'pending_verify') DEFAULT 'active',
            is_identity_verified TINYINT(1) DEFAULT 0,
            is_skill_verified TINYINT(1) DEFAULT 0,
            provider_status ENUM('none', 'pending', 'approved', 'rejected') DEFAULT 'none',
            bio TEXT,
            skills JSON,
            hourly_rate DECIMAL(10,2),
            rating DECIMAL(3,2) DEFAULT 5.00,
            total_earnings DECIMAL(15,2) DEFAULT 0,
            total_spent DECIMAL(15,2) DEFAULT 0,
            completed_orders INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            last_login_at TIMESTAMP NULL,
            INDEX idx_phone (phone),
            INDEX idx_user_type (user_type),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS categories (
            id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(50) NOT NULL,
            icon VARCHAR(100),
            parent_id INT DEFAULT 0,
            sort_order INT DEFAULT 0,
            status TINYINT(1) DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_parent (parent_id),
            INDEX idx_sort (sort_order)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS services (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            user_id BIGINT NOT NULL,
            category_id INT,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            images JSON,
            price_min DECIMAL(10,2),
            price_max DECIMAL(10,2),
            delivery_days INT DEFAULT 7,
            revision_count INT DEFAULT 1,
            rating DECIMAL(3,2) DEFAULT 5.00,
            review_count INT DEFAULT 0,
            order_count INT DEFAULT 0,
            is_top TINYINT(1) DEFAULT 0,
            is_featured TINYINT(1) DEFAULT 0,
            status ENUM('active', 'draft', 'paused', 'deleted') DEFAULT 'draft',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user (user_id),
            INDEX idx_category (category_id),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS service_packages (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            service_id BIGINT NOT NULL,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            price DECIMAL(10,2) NOT NULL,
            delivery_days INT DEFAULT 7,
            revision_count INT DEFAULT 1,
            features JSON,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_service (service_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS projects (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            user_id BIGINT NOT NULL,
            category_id INT,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            budget_min DECIMAL(10,2),
            budget_max DECIMAL(10,2),
            deadline DATETIME,
            status ENUM('open', 'in_progress', 'completed', 'cancelled', 'closed') DEFAULT 'open',
            skills JSON,
            attachment_urls JSON,
            proposals_count INT DEFAULT 0,
            assigned_provider_id BIGINT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user (user_id),
            INDEX idx_category (category_id),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS proposals (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            project_id BIGINT NOT NULL,
            user_id BIGINT NOT NULL,
            price DECIMAL(10,2) NOT NULL,
            duration_days INT NOT NULL,
            cover_letter TEXT,
            status ENUM('pending', 'accepted', 'rejected', 'withdrawn') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_project (project_id),
            INDEX idx_user (user_id),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS orders (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            order_no VARCHAR(50) UNIQUE NOT NULL,
            buyer_id BIGINT NOT NULL,
            seller_id BIGINT NOT NULL,
            type ENUM('service', 'project') NOT NULL,
            source_id BIGINT NOT NULL,
            package_id BIGINT,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            amount DECIMAL(10,2) NOT NULL,
            platform_fee DECIMAL(10,2) DEFAULT 0,
            actual_amount DECIMAL(10,2) NOT NULL,
            status ENUM('pending_payment', 'paid', 'in_progress', 'submitted', 'completed', 'cancelled', 'refunded', 'disputed') DEFAULT 'pending_payment',
            payment_method VARCHAR(20),
            payment_time DATETIME,
            submit_time DATETIME,
            complete_time DATETIME,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_buyer (buyer_id),
            INDEX idx_seller (seller_id),
            INDEX idx_status (status),
            INDEX idx_order_no (order_no)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS wallets (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            user_id BIGINT UNIQUE NOT NULL,
            balance DECIMAL(15,2) DEFAULT 0,
            frozen_amount DECIMAL(15,2) DEFAULT 0,
            total_earnings DECIMAL(15,2) DEFAULT 0,
            total_withdrawn DECIMAL(15,2) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS wallet_transactions (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            wallet_id BIGINT NOT NULL,
            type ENUM('income', 'expense', 'frozen', 'unfrozen', 'withdraw') NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            balance_before DECIMAL(15,2),
            balance_after DECIMAL(15,2),
            source VARCHAR(50),
            source_id BIGINT,
            description VARCHAR(500),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_wallet (wallet_id),
            INDEX idx_type (type),
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS reviews (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            order_id BIGINT UNIQUE NOT NULL,
            reviewer_id BIGINT NOT NULL,
            reviewee_id BIGINT NOT NULL,
            rating TINYINT NOT NULL,
            rating_quality TINYINT,
            rating_communication TINYINT,
            rating_delivery TINYINT,
            comment TEXT,
            reply TEXT,
            reply_time DATETIME,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_order (order_id),
            INDEX idx_reviewer (reviewer_id),
            INDEX idx_reviewee (reviewee_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS withdrawals (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            user_id BIGINT NOT NULL,
            wallet_id BIGINT NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            fee DECIMAL(10,2) DEFAULT 0,
            actual_amount DECIMAL(10,2) NOT NULL,
            bank_name VARCHAR(50),
            bank_account VARCHAR(50),
            bank_holder VARCHAR(50),
            status ENUM('pending', 'approved', 'rejected', 'processing', 'completed', 'failed') DEFAULT 'pending',
            reject_reason VARCHAR(200),
            process_time DATETIME,
            complete_time DATETIME,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_user (user_id),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS refunds (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            order_id BIGINT UNIQUE NOT NULL,
            user_id BIGINT NOT NULL,
            amount DECIMAL(10,2) NOT NULL,
            reason TEXT NOT NULL,
            evidence_urls JSON,
            status ENUM('pending', 'approved', 'rejected', 'refunded') DEFAULT 'pending',
            admin_reply TEXT,
            process_time DATETIME,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_order (order_id),
            INDEX idx_user (user_id),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS messages (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            sender_id BIGINT NOT NULL,
            receiver_id BIGINT NOT NULL,
            order_id BIGINT,
            content TEXT NOT NULL,
            type ENUM('text', 'image', 'file', 'system') DEFAULT 'text',
            is_read TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_sender (sender_id),
            INDEX idx_receiver (receiver_id),
            INDEX idx_order (order_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS notifications (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            user_id BIGINT NOT NULL,
            type VARCHAR(50) NOT NULL,
            title VARCHAR(200) NOT NULL,
            content TEXT,
            data JSON,
            is_read TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_user (user_id),
            INDEX idx_unread (user_id, is_read)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS admin_users (
            id BIGINT PRIMARY KEY AUTO_INCREMENT,
            username VARCHAR(50) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            role VARCHAR(20) DEFAULT 'admin',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,

        `CREATE TABLE IF NOT EXISTS system_config (
            id INT PRIMARY KEY AUTO_INCREMENT,
            config_key VARCHAR(100) UNIQUE NOT NULL,
            config_value TEXT,
            description VARCHAR(200),
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    ];

    for (const query of queries) {
        await pool.query(query);
    }

    // 插入默认分类
    const [cats] = await pool.query('SELECT COUNT(*) as c FROM categories');
    if (cats[0].c === 0) {
        await pool.query(`INSERT INTO categories (name, icon, sort_order) VALUES
            ('Logo设计', 'design', 1),
            ('网站开发', 'code', 2),
            ('APP开发', 'mobile', 3),
            ('视频剪辑', 'video', 4),
            ('文案写作', 'edit', 5),
            ('营销推广', 'campaign', 6),
            ('翻译服务', 'translate', 7),
            ('音乐音频', 'music', 8),
            ('商务咨询', 'business', 9),
            ('其他服务', 'more', 10)`);
    }

    // 插入系统配置
    const [configs] = await pool.query('SELECT COUNT(*) as c FROM system_config');
    if (configs[0].c === 0) {
        await pool.query(`INSERT INTO system_config (config_key, config_value, description) VALUES
            ('platform_fee_percent', '15', '平台抽成百分比'),
            ('min_withdraw_amount', '100', '最低提现金额'),
            ('withdraw_fee_percent', '1', '提现手续费百分比'),
            ('site_name', '灵职集市', '网站名称'),
            ('contact_email', 'support@lingzhijishi.com', '联系邮箱'),
            ('contact_phone', '400-888-8888', '联系电话')`);
    }
    
    // 创建默认管理员
    const [admins] = await pool.query('SELECT COUNT(*) as c FROM admin_users');
    if (admins[0].c === 0) {
        const bcrypt = require('bcryptjs');
        const hashedPassword = await bcrypt.hash('admin123', 10);
        await pool.query('INSERT INTO admin_users (username, password, role) VALUES (?, ?, ?)', ['admin', hashedPassword, 'super_admin']);
    }
}

function getPool() {
    return pool;
}

module.exports = { initDatabase, getPool };
