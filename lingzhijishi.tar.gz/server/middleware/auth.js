const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'lingzhijishi_secret_key_2024';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '7d';

// 生成JWT token
function generateToken(userId) {
    return jwt.sign({ userId }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

// 验证JWT token (用于需要登录的路由)
function verifyToken(req, res, next) {
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
        return res.status(401).json({ error: '请先登录' });
    }
    
    const parts = authHeader.split(' ');
    if (parts.length !== 2 || parts[0] !== 'Bearer') {
        return res.status(401).json({ error: 'token格式错误' });
    }
    
    const token = parts[1];
    
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.userId = decoded.userId;
        next();
    } catch (err) {
        if (err.name === 'TokenExpiredError') {
            return res.status(401).json({ error: 'token已过期' });
        }
        return res.status(401).json({ error: '无效的token' });
    }
}

// 可选认证 - 不强制登录但如果登录了会解析用户
function optionalAuth(req, res, next) {
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
        return next();
    }
    
    const parts = authHeader.split(' ');
    if (parts.length !== 2 || parts[0] !== 'Bearer') {
        return next();
    }
    
    const token = parts[1];
    
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.userId = decoded.userId;
    } catch (err) {
        // 忽略错误，继续
    }
    
    next();
}

// 验证管理员权限
function verifyAdmin(req, res, next) {
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
        return res.status(401).json({ error: '请先登录' });
    }
    
    const parts = authHeader.split(' ');
    if (parts.length !== 2 || parts[0] !== 'Bearer') {
        return res.status(401).json({ error: 'token格式错误' });
    }
    
    const token = parts[1];
    
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.userId = decoded.userId;
        req.isAdmin = true; // 简化处理，实际应该查询用户角色
        next();
    } catch (err) {
        if (err.name === 'TokenExpiredError') {
            return res.status(401).json({ error: 'token已过期' });
        }
        return res.status(401).json({ error: '无效的token' });
    }
}

// 从旧版base64 token兼容获取用户ID
function getUserIdFromAuth(req) {
    const authHeader = req.headers.authorization;
    if (!authHeader) return null;
    
    try {
        const parts = authHeader.split(' ');
        if (parts.length !== 2) return null;
        
        if (parts[0] === 'Bearer') {
            // JWT token
            const decoded = jwt.verify(parts[1], JWT_SECRET);
            return decoded.userId;
        } else {
            // 旧版base64 token
            return parseInt(Buffer.from(parts[1], 'base64').toString().split(':')[0]);
        }
    } catch (err) {
        return null;
    }
}

// 兼容旧版token的中间件
function authCompatible(req, res, next) {
    const userId = getUserIdFromAuth(req);
    if (userId) {
        req.userId = userId;
    }
    next();
}

module.exports = {
    generateToken,
    verifyToken,
    optionalAuth,
    verifyAdmin,
    getUserIdFromAuth,
    authCompatible,
    JWT_SECRET
};
