module.exports = {
  apps: [{
    name: 'lingzhijishi',
    script: 'app.js',
    cwd: '/home/allen/www/lingzhijishi/server',
    args: [],
    instances: 1,
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '500M',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    },
    error_file: '/home/allen/.pm2/logs/lingzhijishi-error.log',
    out_file: '/home/allen/.pm2/logs/lingzhijishi-out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
    merge_logs: true,
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s',
    restart_delay: 1000
  }]
};
