const express = require('express');
const router = express.Router();
const { getPool } = require('../config/database');

// 获取服务商评价列表
router.get('/provider/:userId', async (req, res) => {
    try {
        const { userId } = req.params;
        const { page = 1, pageSize = 10 } = req.query;
        
        const pool = getPool();
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(
            'SELECT COUNT(*) as total FROM reviews WHERE target_user_id = ?',
            [userId]
        );
        
        const [rows] = await pool.query(`
            SELECT r.*, o.title as order_title,
                   buyer.nickname as reviewer_name, buyer.avatar as reviewer_avatar
            FROM reviews r
            LEFT JOIN orders o ON r.order_id = o.id
            LEFT JOIN users buyer ON r.user_id = buyer.id
            WHERE r.target_user_id = ?
            ORDER BY r.created_at DESC
            LIMIT ? OFFSET ?
        `, [userId, parseInt(pageSize), offset]);
        
        res.json({
            list: rows,
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取评价列表错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// 获取订单评价
router.get('/order/:orderId', async (req, res) => {
    try {
        const { orderId } = req.params;
        
        const pool = getPool();
        const [rows] = await pool.query(`
            SELECT r.*, u.nickname as reviewer_name, u.avatar as reviewer_avatar
            FROM reviews r
            LEFT JOIN users u ON r.user_id = u.id
            WHERE r.order_id = ?
        `, [orderId]);
        
        if (rows.length === 0) {
            return res.status(404).json({ error: '评价不存在' });
        }
        
        res.json({ review: rows[0] });
    } catch (error) {
        console.error('获取评价错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// 创建评价
router.post('/create', async (req, res) => {
    try {
        const auth = req.headers.authorization;
        if (!auth) {
            return res.status(401).json({ error: '请先登录' });
        }
        
        const userId = parseInt(Buffer.from(auth.split(' ')[1], 'base64').toString().split(':')[0]);
        const { order_id, target_user_id, rating, content, tags } = req.body;
        
        if (!order_id || !rating || rating < 1 || rating > 5) {
            return res.status(400).json({ error: '请提供有效的评价信息' });
        }
        
        const pool = getPool();
        
        // 检查订单是否已完成
        const [orders] = await pool.query('SELECT * FROM orders WHERE id = ? AND status = ?', [order_id, 'completed']);
        if (orders.length === 0) {
            return res.status(400).json({ error: '订单未完成，无法评价' });
        }
        
        // 检查是否已评价
        const [existing] = await pool.query('SELECT id FROM reviews WHERE order_id = ?', [order_id]);
        if (existing.length > 0) {
            return res.status(400).json({ error: '已评价过此订单' });
        }
        
        // 创建评价
        const [result] = await pool.query(
            'INSERT INTO reviews (order_id, user_id, target_user_id, rating, content, tags) VALUES (?, ?, ?, ?, ?, ?)',
            [order_id, userId, target_user_id, rating, content || '', JSON.stringify(tags || [])]
        );
        
        // 更新目标用户评分
        const [ratingResult] = await pool.query(
            'SELECT AVG(rating) as avg_rating FROM reviews WHERE target_user_id = ?',
            [target_user_id]
        );
        await pool.query('UPDATE users SET rating = ? WHERE id = ?', [ratingResult[0].avg_rating.toFixed(1), target_user_id]);
        
        res.json({ id: result.insertId, message: '评价成功' });
    } catch (error) {
        console.error('创建评价错误:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
