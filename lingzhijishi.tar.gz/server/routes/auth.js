const express = require('express');
const router = express.Router();
const { getPool } = require('../config/database');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { generateToken, verifyToken, JWT_SECRET } = require('../middleware/auth');

// POST /register - 用户注册
router.post('/register', async (req, res) => {
    try {
        const { phone, password, role } = req.body;
        
        if (!phone || !password) {
            return res.status(400).json({ error: '请输入手机号和密码' });
        }
        
        if (password.length < 6) {
            return res.status(400).json({ error: '密码至少6位' });
        }
        
        const pool = getPool();
        
        // 检查手机号是否已注册
        const [existing] = await pool.query('SELECT id FROM users WHERE phone = ?', [phone]);
        if (existing.length > 0) {
            return res.status(400).json({ error: '手机号已注册' });
        }
        
        // 加密密码
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // 创建用户
        const [result] = await pool.query(
            'INSERT INTO users (phone, password, nickname, user_type) VALUES (?, ?, ?, ?)',
            [phone, hashedPassword, phone.slice(-4), role || 'both']
        );
        
        const userId = result.insertId;
        
        // 创建钱包
        await pool.query('INSERT INTO wallets (user_id, balance) VALUES (?, 0)', [userId]);
        
        // 生成JWT token
        const token = generateToken(userId);
        
        res.json({
            token,
            user: {
                id: userId,
                phone,
                nickname: phone.slice(-4),
                user_type: role || 'both'
            }
        });
    } catch (error) {
        console.error('注册错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /login - 用户登录
router.post('/login', async (req, res) => {
    try {
        const { phone, password } = req.body;
        
        if (!phone || !password) {
            return res.status(400).json({ error: '请输入手机号和密码' });
        }
        
        const pool = getPool();
        const [rows] = await pool.query('SELECT * FROM users WHERE phone = ?', [phone]);
        
        if (rows.length === 0) {
            return res.status(401).json({ error: '手机号或密码错误' });
        }
        
        const user = rows[0];
        const isValid = await bcrypt.compare(password, user.password);
        
        if (!isValid) {
            return res.status(401).json({ error: '手机号或密码错误' });
        }
        
        if (user.status === 'disabled' || user.status === 'banned') {
            return res.status(403).json({ error: '账号已被禁用' });
        }
        
        // 更新最后登录时间
        await pool.query('UPDATE users SET last_login_at = NOW() WHERE id = ?', [user.id]);
        
        // 生成JWT token
        const token = generateToken(user.id);
        
        res.json({
            token,
            user: {
                id: user.id,
                phone: user.phone,
                nickname: user.nickname,
                avatar: user.avatar,
                user_type: user.user_type,
                status: user.status,
                is_identity_verified: user.is_identity_verified,
                is_skill_verified: user.is_skill_verified,
                provider_status: user.provider_status
            }
        });
    } catch (error) {
        console.error('登录错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /logout - 用户登出
router.post('/logout', verifyToken, async (req, res) => {
    try {
        // JWT stateless - 客户端删除token即可
        // 如果需要服务端blacklist可以扩展
        res.json({ message: '登出成功' });
    } catch (error) {
        console.error('登出错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /profile - 获取个人资料
router.get('/profile', verifyToken, async (req, res) => {
    try {
        const pool = getPool();
        const [rows] = await pool.query(
            `SELECT id, phone, nickname, avatar, user_type, email, real_name, 
             is_identity_verified, is_skill_verified, provider_status, bio, skills, 
             hourly_rate, rating, total_earnings, total_spent, completed_orders, created_at 
             FROM users WHERE id = ?`,
            [req.userId]
        );
        
        if (rows.length === 0) {
            return res.status(404).json({ error: '用户不存在' });
        }
        
        const user = rows[0];
        user.skills = user.skills ? JSON.parse(user.skills) : [];
        
        res.json({ user });
    } catch (error) {
        console.error('获取资料错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /profile - 更新个人资料
router.put('/profile', verifyToken, async (req, res) => {
    try {
        const { nickname, avatar, email, real_name, bio, skills, hourly_rate } = req.body;
        
        const pool = getPool();
        await pool.query(
            `UPDATE users SET 
             nickname = ?, avatar = ?, email = ?, real_name = ?, 
             bio = ?, skills = ?, hourly_rate = ? 
             WHERE id = ?`,
            [nickname, avatar, email, real_name, bio, skills ? JSON.stringify(skills) : null, hourly_rate, req.userId]
        );
        
        res.json({ message: '资料更新成功' });
    } catch (error) {
        console.error('更新资料错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /change-password - 修改密码
router.post('/change-password', verifyToken, async (req, res) => {
    try {
        const { old_password, new_password } = req.body;
        
        if (!old_password || !new_password) {
            return res.status(400).json({ error: '请填写完整' });
        }
        
        if (new_password.length < 6) {
            return res.status(400).json({ error: '新密码至少6位' });
        }
        
        const pool = getPool();
        const [rows] = await pool.query('SELECT password FROM users WHERE id = ?', [req.userId]);
        
        const isValid = await bcrypt.compare(old_password, rows[0].password);
        if (!isValid) {
            return res.status(401).json({ error: '原密码错误' });
        }
        
        const hashedPassword = await bcrypt.hash(new_password, 10);
        await pool.query('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, req.userId]);
        
        res.json({ message: '密码修改成功' });
    } catch (error) {
        console.error('修改密码错误:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
