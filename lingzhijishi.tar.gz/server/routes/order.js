const express = require('express');
const router = express.Router();
const { getPool } = require('../config/database');
const { verifyToken } = require('../middleware/auth');
const { v4: uuidv4 } = require('uuid');

// 生成订单号
function generateOrderNo() {
    return 'LZJ' + Date.now() + uuidv4().slice(0, 4).toUpperCase();
}

// GET /list - 获取订单列表
router.get('/list', verifyToken, async (req, res) => {
    try {
        const { status, role, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        let where = 'WHERE (buyer_id = ? OR seller_id = ?)';
        const params = [req.userId, req.userId];
        
        if (status) {
            where += ' AND o.status = ?';
            params.push(status);
        }
        
        if (role === 'buyer') {
            where = 'WHERE buyer_id = ?';
            params = [req.userId];
            if (status) {
                where += ' AND o.status = ?';
                params.push(status);
            }
        } else if (role === 'seller') {
            where = 'WHERE seller_id = ?';
            params = [req.userId];
            if (status) {
                where += ' AND o.status = ?';
                params.push(status);
            }
        }
        
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM orders o ${where}`, params);
        
        const [rows] = await pool.query(`
            SELECT o.*, 
                   buyer.nickname as buyer_name, buyer.avatar as buyer_avatar,
                   seller.nickname as seller_name, seller.avatar as seller_avatar
            FROM orders o
            LEFT JOIN users buyer ON o.buyer_id = buyer.id
            LEFT JOIN users seller ON o.seller_id = seller.id
            ${where}
            ORDER BY o.created_at DESC
            LIMIT ? OFFSET ?
        `, [...params, parseInt(pageSize), offset]);
        
        res.json({
            list: rows,
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取订单列表错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /detail/:id - 获取订单详情
router.get('/detail/:id', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        
        const pool = getPool();
        
        const [rows] = await pool.query(`
            SELECT o.*,
                   buyer.nickname as buyer_name, buyer.avatar as buyer_avatar, buyer.phone as buyer_phone,
                   seller.nickname as seller_name, seller.avatar as seller_avatar, seller.phone as seller_phone
            FROM orders o
            LEFT JOIN users buyer ON o.buyer_id = buyer.id
            LEFT JOIN users seller ON o.seller_id = seller.id
            WHERE o.id = ?
        `, [id]);
        
        if (rows.length === 0) {
            return res.status(404).json({ error: '订单不存在' });
        }
        
        const order = rows[0];
        
        // 验证权限
        if (order.buyer_id !== req.userId && order.seller_id !== req.userId) {
            return res.status(403).json({ error: '无权查看此订单' });
        }
        
        // 获取套餐信息
        if (order.package_id) {
            const [packages] = await pool.query('SELECT * FROM service_packages WHERE id = ?', [order.package_id]);
            if (packages.length > 0) {
                order.package = {
                    ...packages[0],
                    features: packages[0].features ? JSON.parse(packages[0].features) : []
                };
            }
        }
        
        res.json({ order });
    } catch (error) {
        console.error('获取订单详情错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /create - 创建订单
router.post('/create', verifyToken, async (req, res) => {
    try {
        const { project_id, service_id, package_id, description } = req.body;
        
        if (!service_id && !project_id) {
            return res.status(400).json({ error: '请选择服务或项目' });
        }
        
        const pool = getPool();
        const connection = await pool.getConnection();
        
        try {
            await connection.beginTransaction();
            
            let amount, delivery_days, title, seller_id, source_id, type;
            
            if (service_id) {
                // 服务订单
                const [services] = await connection.query('SELECT * FROM services WHERE id = ?', [service_id]);
                if (services.length === 0) {
                    await connection.rollback();
                    return res.status(404).json({ error: '服务不存在' });
                }
                
                const service = services[0];
                seller_id = service.user_id;
                source_id = service_id;
                type = 'service';
                title = service.title;
                
                if (package_id) {
                    const [packages] = await connection.query('SELECT * FROM service_packages WHERE id = ?', [package_id]);
                    if (packages.length === 0) {
                        await connection.rollback();
                        return res.status(404).json({ error: '套餐不存在' });
                    }
                    amount = packages[0].price;
                    delivery_days = packages[0].delivery_days;
                } else {
                    amount = service.price_min || 0;
                    delivery_days = service.delivery_days;
                }
            } else {
                // 项目订单
                const [projects] = await connection.query('SELECT * FROM projects WHERE id = ?', [project_id]);
                if (projects.length === 0) {
                    await connection.rollback();
                    return res.status(404).json({ error: '项目不存在' });
                }
                
                const project = projects[0];
                seller_id = project.assigned_provider_id;
                source_id = project_id;
                type = 'project';
                title = project.title;
                amount = project.budget_max || project.budget_min || 0;
                delivery_days = null;
            }
            
            if (seller_id === req.userId) {
                await connection.rollback();
                return res.status(400).json({ error: '不能购买自己的服务' });
            }
            
            // 计算平台费
            const platform_fee = amount * 0.15;
            const actual_amount = amount - platform_fee;
            
            const orderNo = generateOrderNo();
            
            const [result] = await connection.query(
                `INSERT INTO orders (order_no, buyer_id, seller_id, type, source_id, package_id, title, description, amount, platform_fee, actual_amount, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending_payment')`,
                [orderNo, req.userId, seller_id, type, source_id, package_id, title, description || '', amount, platform_fee, actual_amount]
            );
            
            await connection.commit();
            res.json({ order_id: result.insertId, order_no: orderNo, amount, message: '订单创建成功' });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('创建订单错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /update/:id/status - 更新订单状态
router.put('/update/:id/status', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        
        const pool = getPool();
        const connection = await pool.getConnection();
        
        try {
            await connection.beginTransaction();
            
            const [orders] = await connection.query('SELECT * FROM orders WHERE id = ?', [id]);
            if (orders.length === 0) {
                await connection.rollback();
                return res.status(404).json({ error: '订单不存在' });
            }
            
            const order = orders[0];
            
            // 验证权限和状态转换
            const validTransitions = {
                'pending_payment': ['paid', 'cancelled'],
                'paid': ['in_progress', 'cancelled'],
                'in_progress': ['submitted'],
                'submitted': ['completed', 'disputed'],
                'completed': [],
                'cancelled': [],
                'refunded': [],
                'disputed': ['completed', 'refunded']
            };
            
            if (!validTransitions[order.status] || !validTransitions[order.status].includes(status)) {
                await connection.rollback();
                return res.status(400).json({ error: '无效的状态转换' });
            }
            
            // 验证权限
            if (status === 'in_progress' && order.seller_id !== req.userId) {
                await connection.rollback();
                return res.status(403).json({ error: '只有服务商可以开始工作' });
            }
            
            if (status === 'submitted' && order.seller_id !== req.userId) {
                await connection.rollback();
                return res.status(403).json({ error: '只有服务商可以提交成果' });
            }
            
            if (status === 'completed' && order.buyer_id !== req.userId) {
                await connection.rollback();
                return res.status(403).json({ error: '只有雇主可以确认完成' });
            }
            
            if (status === 'cancelled' && order.buyer_id !== req.userId && order.seller_id !== req.userId) {
                await connection.rollback();
                return res.status(403).json({ error: '无权取消此订单' });
            }
            
            // 处理状态变更
            if (status === 'paid') {
                // 支付订单
                const [wallets] = await connection.query('SELECT * FROM wallets WHERE user_id = ?', [req.userId]);
                if (wallets.length === 0 || wallets[0].balance < order.actual_amount) {
                    await connection.rollback();
                    return res.status(400).json({ error: '余额不足' });
                }
                
                await connection.query('UPDATE wallets SET balance = balance - ? WHERE user_id = ?', 
                    [order.actual_amount, req.userId]);
                
                await connection.query(
                    `INSERT INTO wallet_transactions (wallet_id, type, amount, balance_before, balance_after, source, source_id, description)
                     SELECT w.id, 'expense', ?, w.balance, w.balance - ?, 'order_payment', ?, CONCAT('支付订单:', ?) FROM wallets w WHERE w.user_id = ?`,
                    [order.actual_amount, order.actual_amount, id, order.order_no, req.userId]
                );
                
                await connection.query('UPDATE orders SET status = ?, payment_method = ?, payment_time = NOW() WHERE id = ?', 
                    ['paid', 'wallet', id]);
                    
            } else if (status === 'in_progress') {
                await connection.query('UPDATE orders SET status = ? WHERE id = ?', ['in_progress', id]);
                
            } else if (status === 'submitted') {
                await connection.query('UPDATE orders SET status = ?, submit_time = NOW() WHERE id = ?', ['submitted', id]);
                
            } else if (status === 'completed') {
                // 完成订单，转账给卖家
                await connection.query('UPDATE orders SET status = ?, complete_time = NOW() WHERE id = ?', ['completed', id]);
                
                await connection.query('UPDATE wallets SET balance = balance + ?, total_earnings = total_earnings + ? WHERE user_id = ?', 
                    [order.actual_amount, order.actual_amount, order.seller_id]);
                
                await connection.query('UPDATE users SET completed_orders = completed_orders + 1, total_earnings = total_earnings + ? WHERE id = ?', 
                    [order.actual_amount, order.seller_id]);
                await connection.query('UPDATE users SET total_spent = total_spent + ? WHERE id = ?', 
                    [order.amount, order.buyer_id]);
                
                if (order.type === 'service') {
                    await connection.query('UPDATE services SET order_count = order_count + 1 WHERE id = ?', [order.source_id]);
                }
                
                await connection.query(
                    `INSERT INTO wallet_transactions (wallet_id, type, amount, balance_before, balance_after, source, source_id, description)
                     SELECT w.id, 'income', ?, w.balance - ?, w.balance, 'order_complete', ?, CONCAT('订单完成收入:', ?) FROM wallets w WHERE w.user_id = ?`,
                    [order.actual_amount, order.actual_amount, id, order.order_no, order.seller_id]
                );
                
            } else if (status === 'cancelled') {
                // 取消订单，退款
                if (order.status === 'paid') {
                    await connection.query('UPDATE wallets SET balance = balance + ? WHERE user_id = ?', 
                        [order.actual_amount, order.buyer_id]);
                    
                    await connection.query(
                        `INSERT INTO wallet_transactions (wallet_id, type, amount, balance_before, balance_after, source, source_id, description)
                         SELECT w.id, 'income', ?, w.balance, w.balance + ?, 'order_refund', ?, CONCAT('订单取消退款:', ?) FROM wallets w WHERE w.user_id = ?`,
                        [order.actual_amount, order.actual_amount, id, order.order_no, order.buyer_id]
                    );
                }
                
                await connection.query('UPDATE orders SET status = ? WHERE id = ?', ['cancelled', id]);
            }
            
            await connection.commit();
            res.json({ message: '状态更新成功' });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('更新订单状态错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /cancel/:id - 取消订单
router.post('/cancel/:id', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const { reason } = req.body;
        
        const pool = getPool();
        const connection = await pool.getConnection();
        
        try {
            await connection.beginTransaction();
            
            const [orders] = await connection.query('SELECT * FROM orders WHERE id = ?', [id]);
            if (orders.length === 0) {
                await connection.rollback();
                return res.status(404).json({ error: '订单不存在' });
            }
            
            const order = orders[0];
            
            if (order.buyer_id !== req.userId && order.seller_id !== req.userId) {
                await connection.rollback();
                return res.status(403).json({ error: '无权操作此订单' });
            }
            
            if (!['pending_payment', 'paid'].includes(order.status)) {
                await connection.rollback();
                return res.status(400).json({ error: '当前状态无法取消' });
            }
            
            // 如果已支付，退款
            if (order.status === 'paid') {
                await connection.query('UPDATE wallets SET balance = balance + ? WHERE user_id = ?', 
                    [order.actual_amount, order.buyer_id]);
                
                await connection.query(
                    `INSERT INTO wallet_transactions (wallet_id, type, amount, balance_before, balance_after, source, source_id, description)
                     SELECT w.id, 'income', ?, w.balance, w.balance + ?, 'order_refund', ?, CONCAT('订单取消退款:', ?) FROM wallets w WHERE w.user_id = ?`,
                    [order.actual_amount, order.actual_amount, id, order.order_no, order.buyer_id]
                );
            }
            
            await connection.query('UPDATE orders SET status = ? WHERE id = ?', ['cancelled', id]);
            
            await connection.commit();
            res.json({ message: '订单已取消' });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('取消订单错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /stats - 获取订单统计
router.get('/stats', verifyToken, async (req, res) => {
    try {
        const pool = getPool();
        
        // 买家统计
        const [buyerStats] = await pool.query(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
                SUM(CASE WHEN status = 'pending_payment' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
                SUM(CASE WHEN status = 'submitted' THEN 1 ELSE 0 END) as submitted,
                SUM(CASE WHEN status = 'completed' THEN amount ELSE 0 END) as total_spent
            FROM orders WHERE buyer_id = ?
        `, [req.userId]);
        
        // 卖家统计
        const [sellerStats] = await pool.query(`
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
                SUM(CASE WHEN status = 'pending_payment' OR status = 'paid' OR status = 'in_progress' OR status = 'submitted' THEN 1 ELSE 0 END) as processing,
                SUM(CASE WHEN status = 'completed' THEN actual_amount ELSE 0 END) as total_earnings
            FROM orders WHERE seller_id = ?
        `, [req.userId]);
        
        res.json({
            as_buyer: buyerStats[0],
            as_seller: sellerStats[0]
        });
    } catch (error) {
        console.error('获取订单统计错误:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
