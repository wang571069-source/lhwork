const express = require('express');
const router = express.Router();
const { getPool } = require('../config/database');
const { verifyToken } = require('../middleware/auth');

// GET /list - 获取会话列表
router.get('/list', verifyToken, async (req, res) => {
    try {
        const pool = getPool();
        
        // 获取与当前用户的所有对话（按最新消息排序）
        const [conversations] = await pool.query(`
            SELECT 
                CASE 
                    WHEN m.sender_id = ? THEN m.receiver_id 
                    ELSE m.sender_id 
                END as partner_id,
                MAX(m.id) as last_message_id,
                MAX(m.created_at) as last_time
            FROM messages m
            WHERE m.sender_id = ? OR m.receiver_id = ?
            GROUP BY partner_id
            ORDER BY last_time DESC
        `, [req.userId, req.userId, req.userId]);
        
        // 获取每个对话的详细信息
        const list = [];
        for (const conv of conversations) {
            const [messages] = await pool.query(`
                SELECT m.*, 
                       sender.nickname as sender_name, sender.avatar as sender_avatar,
                       receiver.nickname as receiver_name, receiver.avatar as receiver_avatar
                FROM messages m
                LEFT JOIN users sender ON m.sender_id = sender.id
                LEFT JOIN users receiver ON m.receiver_id = receiver.id
                WHERE m.id = ?
            `, [conv.last_message_id]);
            
            const [partner] = await pool.query(`
                SELECT id, nickname, avatar, user_type FROM users WHERE id = ?
            `, [conv.partner_id]);
            
            const [unread] = await pool.query(`
                SELECT COUNT(*) as count FROM messages 
                WHERE sender_id = ? AND receiver_id = ? AND is_read = 0
            `, [conv.partner_id, req.userId]);
            
            if (messages.length > 0 && partner.length > 0) {
                list.push({
                    partner: partner[0],
                    last_message: messages[0],
                    unread_count: unread[0].count
                });
            }
        }
        
        res.json({ list });
    } catch (error) {
        console.error('获取会话列表错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /detail/:conversation_id - 获取对话详情（与某用户的所有消息）
router.get('/detail/:conversation_id', verifyToken, async (req, res) => {
    try {
        const { conversation_id } = req.params;
        const { page = 1, pageSize = 50 } = req.query;
        
        const partnerId = parseInt(conversation_id);
        if (isNaN(partnerId)) {
            return res.status(400).json({ error: '无效的会话ID' });
        }
        
        const pool = getPool();
        const offset = (page - 1) * pageSize;
        
        // 获取对话消息
        const [messages] = await pool.query(`
            SELECT m.*,
                   sender.nickname as sender_name, sender.avatar as sender_avatar,
                   receiver.nickname as receiver_name, receiver.avatar as receiver_avatar
            FROM messages m
            LEFT JOIN users sender ON m.sender_id = sender.id
            LEFT JOIN users receiver ON m.receiver_id = receiver.id
            WHERE (m.sender_id = ? AND m.receiver_id = ?) 
               OR (m.sender_id = ? AND m.receiver_id = ?)
            ORDER BY m.created_at DESC
            LIMIT ? OFFSET ?
        `, [req.userId, partnerId, partnerId, req.userId, parseInt(pageSize), offset]);
        
        // 标记这些消息为已读
        await pool.query(`
            UPDATE messages SET is_read = 1 
            WHERE sender_id = ? AND receiver_id = ? AND is_read = 0
        `, [partnerId, req.userId]);
        
        // 获取对方信息
        const [partner] = await pool.query(`
            SELECT id, nickname, avatar, user_type, rating FROM users WHERE id = ?
        `, [partnerId]);
        
        res.json({ 
            messages: messages.reverse(),
            partner: partner.length > 0 ? partner[0] : null,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取对话详情错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /send - 发送消息
router.post('/send', verifyToken, async (req, res) => {
    try {
        const { to_user_id, content, project_id, type = 'text' } = req.body;
        
        if (!to_user_id || !content) {
            return res.status(400).json({ error: '请填写收件人和内容' });
        }
        
        if (to_user_id === req.userId) {
            return res.status(400).json({ error: '不能给自己发消息' });
        }
        
        const pool = getPool();
        
        // 检查收件人是否存在
        const [users] = await pool.query('SELECT id FROM users WHERE id = ?', [to_user_id]);
        if (users.length === 0) {
            return res.status(404).json({ error: '用户不存在' });
        }
        
        const [result] = await pool.query(
            'INSERT INTO messages (sender_id, receiver_id, order_id, content, type) VALUES (?, ?, ?, ?, ?)',
            [req.userId, to_user_id, project_id || null, content, type]
        );
        
        res.json({ id: result.insertId, message: '发送成功' });
    } catch (error) {
        console.error('发送消息错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /read/:id - 标记消息已读
router.put('/read/:id', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        
        const pool = getPool();
        const [result] = await pool.query(
            'UPDATE messages SET is_read = 1 WHERE id = ? AND receiver_id = ?',
            [id, req.userId]
        );
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: '消息不存在或无权操作' });
        }
        
        res.json({ message: '已标记为已读' });
    } catch (error) {
        console.error('标记已读错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /unread-count - 获取未读消息数
router.get('/unread-count', verifyToken, async (req, res) => {
    try {
        const pool = getPool();
        const [result] = await pool.query(
            'SELECT COUNT(*) as count FROM messages WHERE receiver_id = ? AND is_read = 0',
            [req.userId]
        );
        
        res.json({ count: result[0].count });
    } catch (error) {
        console.error('获取未读数错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /read-conversation/:partner_id - 标记与某人的对话已读
router.put('/read-conversation/:partner_id', verifyToken, async (req, res) => {
    try {
        const { partner_id } = req.params;
        
        const pool = getPool();
        await pool.query(`
            UPDATE messages SET is_read = 1 
            WHERE sender_id = ? AND receiver_id = ? AND is_read = 0
        `, [partner_id, req.userId]);
        
        res.json({ message: '已标记为已读' });
    } catch (error) {
        console.error('标记对话已读错误:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
