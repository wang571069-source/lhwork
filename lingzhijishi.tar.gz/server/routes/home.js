const express = require('express');
const router = express.Router();
const { getPool } = require('../config/database');

// 获取首页数据
router.get('/data', async (req, res) => {
    try {
        const pool = getPool();
        
        // 获取统计数据
        const [stats] = await pool.query(`
            SELECT 
                (SELECT COUNT(*) FROM users) as total_users,
                (SELECT COUNT(*) FROM users WHERE provider_status = 'approved') as total_providers,
                (SELECT COUNT(*) FROM orders WHERE status = 'completed') as total_orders,
                (SELECT AVG(rating) FROM users WHERE rating > 0) as avg_rating
        `);
        
        // 获取热门服务（置顶/精选）
        const [featuredServices] = await pool.query(`
            SELECT s.*, u.nickname as seller_name, u.avatar as seller_avatar, u.rating as seller_rating,
                   c.name as category_name
            FROM services s
            LEFT JOIN users u ON s.user_id = u.id
            LEFT JOIN categories c ON s.category_id = c.id
            WHERE s.status = 'active'
            ORDER BY s.is_featured DESC, s.is_top DESC, s.order_count DESC
            LIMIT 8
        `);
        
        // 获取最新服务
        const [latestServices] = await pool.query(`
            SELECT s.*, u.nickname as seller_name, u.avatar as seller_avatar,
                   c.name as category_name
            FROM services s
            LEFT JOIN users u ON s.user_id = u.id
            LEFT JOIN categories c ON s.category_id = c.id
            WHERE s.status = 'active'
            ORDER BY s.created_at DESC
            LIMIT 8
        `);
        
        // 获取开放项目
        const [openProjects] = await pool.query(`
            SELECT p.*, u.nickname as employer_name, u.avatar as employer_avatar,
                   c.name as category_name
            FROM projects p
            LEFT JOIN users u ON p.user_id = u.id
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.status = 'open'
            ORDER BY p.created_at DESC
            LIMIT 6
        `);
        
        // 获取分类
        const [categories] = await pool.query('SELECT * FROM categories WHERE status = 1 ORDER BY sort_order LIMIT 10');
        
        // 处理图片
        const processServices = (services) => services.map(s => ({
            ...s,
            images: s.images ? JSON.parse(s.images) : []
        }));
        
        res.json({
            stats: {
                total_users: stats[0].total_users || 0,
                total_providers: stats[0].total_providers || 0,
                total_orders: stats[0].total_orders || 0,
                avg_rating: (stats[0].avg_rating || 5).toFixed(1)
            },
            featured_services: processServices(featuredServices),
            latest_services: processServices(latestServices),
            open_projects: openProjects.map(p => ({
                ...p,
                skills: p.skills ? JSON.parse(p.skills) : []
            })),
            categories
        });
    } catch (error) {
        console.error('获取首页数据错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// 获取统计数据（数字）
router.get('/stats', async (req, res) => {
    try {
        const pool = getPool();
        const [stats] = await pool.query(`
            SELECT 
                (SELECT COUNT(*) FROM users) as total_users,
                (SELECT COUNT(*) FROM users WHERE provider_status = 'approved') as total_providers,
                (SELECT COUNT(*) FROM orders WHERE status = 'completed') as total_orders
        `);
        
        res.json({
            total_users: stats[0].total_users || 0,
            total_providers: stats[0].total_providers || 0,
            total_orders: stats[0].total_orders || 0
        });
    } catch (error) {
        console.error('获取统计数据错误:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
