const express = require('express');
const router = express.Router();
const { getPool } = require('../config/database');
const { verifyToken } = require('../middleware/auth');

// GET /list - 获取通知列表
router.get('/list', verifyToken, async (req, res) => {
    try {
        const { is_read, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        let where = 'WHERE user_id = ?';
        const params = [req.userId];
        
        if (is_read !== undefined) {
            where += ' AND is_read = ?';
            params.push(is_read === 'true' || is_read === '1' ? 1 : 0);
        }
        
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM notifications ${where}`, params);
        
        const [rows] = await pool.query(
            `SELECT * FROM notifications ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
            [...params, parseInt(pageSize), offset]
        );
        
        res.json({
            list: rows.map(r => ({ ...r, data: r.data ? JSON.parse(r.data) : null })),
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取通知列表错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /read/:id - 标记单条通知已读
router.put('/read/:id', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        
        const pool = getPool();
        const [result] = await pool.query(
            'UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?',
            [id, req.userId]
        );
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: '通知不存在' });
        }
        
        res.json({ message: '已标记为已读' });
    } catch (error) {
        console.error('标记已读错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /read-all - 标记全部通知已读
router.put('/read-all', verifyToken, async (req, res) => {
    try {
        const pool = getPool();
        await pool.query('UPDATE notifications SET is_read = 1 WHERE user_id = ?', [req.userId]);
        
        res.json({ message: '全部已读' });
    } catch (error) {
        console.error('标记全部已读错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /unread-count - 获取未读通知数
router.get('/unread-count', verifyToken, async (req, res) => {
    try {
        const pool = getPool();
        const [result] = await pool.query(
            'SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0',
            [req.userId]
        );
        
        res.json({ count: result[0].count });
    } catch (error) {
        console.error('获取未读数错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// DELETE /:id - 删除通知
router.delete('/:id', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        
        const pool = getPool();
        const [result] = await pool.query(
            'DELETE FROM notifications WHERE id = ? AND user_id = ?',
            [id, req.userId]
        );
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: '通知不存在' });
        }
        
        res.json({ message: '删除成功' });
    } catch (error) {
        console.error('删除通知错误:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
