const express = require('express');
const router = express.Router();
const { getPool } = require('../config/database');
const { verifyToken } = require('../middleware/auth');

// GET /list - 获取用户列表
router.get('/list', async (req, res) => {
    try {
        const { search, role, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        let where = 'WHERE status = "active"';
        const params = [];
        
        if (search) {
            where += ' AND (phone LIKE ? OR nickname LIKE ?)';
            params.push(`%${search}%`, `%${search}%`);
        }
        
        if (role) {
            where += ' AND user_type = ?';
            params.push(role);
        }
        
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM users ${where}`, params);
        
        const [rows] = await pool.query(`
            SELECT id, phone, nickname, avatar, user_type, provider_status, rating, completed_orders, created_at
            FROM users ${where}
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        `, [...params, parseInt(pageSize), offset]);
        
        res.json({
            list: rows,
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取用户列表错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /detail/:id - 获取用户详情
router.get('/detail/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        const pool = getPool();
        const [rows] = await pool.query(`
            SELECT id, phone, nickname, avatar, user_type, bio, skills, hourly_rate, 
                   rating, completed_orders, created_at, provider_status, is_identity_verified, is_skill_verified
            FROM users WHERE id = ? AND status = 'active'
        `, [id]);
        
        if (rows.length === 0) {
            return res.status(404).json({ error: '用户不存在' });
        }
        
        const user = rows[0];
        user.skills = user.skills ? JSON.parse(user.skills) : [];
        
        res.json({ user });
    } catch (error) {
        console.error('获取用户详情错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /update/:id - 更新用户
router.put('/update/:id', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        
        // 只有本人可以更新自己的信息
        if (parseInt(id) !== req.userId) {
            return res.status(403).json({ error: '无权修改此用户' });
        }
        
        const { nickname, avatar, email, real_name, bio, skills, hourly_rate } = req.body;
        
        const pool = getPool();
        await pool.query(
            `UPDATE users SET 
             nickname = ?, avatar = ?, email = ?, real_name = ?, 
             bio = ?, skills = ?, hourly_rate = ?
             WHERE id = ?`,
            [nickname, avatar, email, real_name, bio, skills ? JSON.stringify(skills) : null, hourly_rate, id]
        );
        
        res.json({ message: '用户更新成功' });
    } catch (error) {
        console.error('更新用户错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /verify - 提交认证资料
router.put('/verify', verifyToken, async (req, res) => {
    try {
        const { real_name, id_card, id_card_front, id_card_back, skills, hourly_rate, bio } = req.body;
        
        if (!real_name || !id_card) {
            return res.status(400).json({ error: '请填写完整的身份信息' });
        }
        
        const pool = getPool();
        
        // 更新身份信息和申请成为服务商
        await pool.query(
            `UPDATE users SET 
             real_name = ?, id_card = ?, id_card_front = ?, id_card_back = ?,
             skills = ?, hourly_rate = ?, bio = ?,
             provider_status = 'pending',
             user_type = CASE WHEN user_type = 'employer' THEN 'both' ELSE user_type END
             WHERE id = ?`,
            [real_name, id_card, id_card_front, id_card_back, 
             skills ? JSON.stringify(skills) : null, hourly_rate, bio, req.userId]
        );
        
        res.json({ message: '认证资料已提交，等待审核' });
    } catch (error) {
        console.error('提交认证错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /my-services - 获取我的服务（服务商视角）
router.get('/my-services', verifyToken, async (req, res) => {
    try {
        const { status, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        let where = 'WHERE user_id = ?';
        const params = [req.userId];
        
        if (status) {
            where += ' AND status = ?';
            params.push(status);
        }
        
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM services ${where}`, params);
        
        const [rows] = await pool.query(
            `SELECT s.*, c.name as category_name
             FROM services s
             LEFT JOIN categories c ON s.category_id = c.id
             ${where}
             ORDER BY s.created_at DESC
             LIMIT ? OFFSET ?`,
            [...params, parseInt(pageSize), offset]
        );
        
        res.json({
            list: rows.map(r => ({ ...r, images: r.images ? JSON.parse(r.images) : [] })),
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取我的服务错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /my-projects - 获取我的项目（雇主视角）
router.get('/my-projects', verifyToken, async (req, res) => {
    try {
        const { status, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        let where = 'WHERE user_id = ?';
        const params = [req.userId];
        
        if (status) {
            where += ' AND status = ?';
            params.push(status);
        }
        
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM projects ${where}`, params);
        
        const [rows] = await pool.query(
            `SELECT p.*, c.name as category_name
             FROM projects p
             LEFT JOIN categories c ON p.category_id = c.id
             ${where}
             ORDER BY p.created_at DESC
             LIMIT ? OFFSET ?`,
            [...params, parseInt(pageSize), offset]
        );
        
        res.json({
            list: rows.map(r => ({ ...r, skills: r.skills ? JSON.parse(r.skills) : [] })),
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取我的项目错误:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
