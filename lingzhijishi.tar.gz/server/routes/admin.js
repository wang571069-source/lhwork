const express = require('express');
const router = express.Router();
const { getPool } = require('../config/database');
const { verifyAdmin, generateToken } = require('../middleware/auth');
const bcrypt = require('bcryptjs');

// POST /login - 管理员登录
router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        
        if (!username || !password) {
            return res.status(400).json({ error: '请输入用户名和密码' });
        }
        
        const pool = getPool();
        
        // 检查是否有admin_users表
        try {
            const [admins] = await pool.query('SELECT * FROM admin_users WHERE username = ?', [username]);
            
            if (admins.length > 0) {
                const admin = admins[0];
                const isValid = await bcrypt.compare(password, admin.password);
                
                if (!isValid) {
                    return res.status(401).json({ error: '用户名或密码错误' });
                }
                
                const token = generateToken(admin.id);
                return res.json({ 
                    token, 
                    admin: { 
                        id: admin.id, 
                        username: admin.username, 
                        role: admin.role 
                    } 
                });
            }
        } catch (e) {
            // admin_users表不存在，使用简单的管理员验证
        }
        
        // 简单的内置管理员验证（生产环境应该用admin_users表）
        if (username === 'admin' && password === 'admin123') {
            const token = generateToken(0); // 0表示超级管理员
            return res.json({ 
                token, 
                admin: { 
                    id: 0, 
                    username: 'admin', 
                    role: 'super_admin' 
                } 
            });
        }
        
        res.status(401).json({ error: '用户名或密码错误' });
    } catch (error) {
        console.error('管理员登录错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /dashboard - 获取仪表盘统计数据
router.get('/dashboard', verifyAdmin, async (req, res) => {
    try {
        const pool = getPool();
        
        const [stats] = await pool.query(`
            SELECT 
                (SELECT COUNT(*) FROM users) as total_users,
                (SELECT COUNT(*) FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)) as new_users_this_week,
                (SELECT COUNT(*) FROM services WHERE status = 'active') as total_services,
                (SELECT COUNT(*) FROM services WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)) as new_services_this_week,
                (SELECT COUNT(*) FROM projects) as total_projects,
                (SELECT COUNT(*) FROM projects WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)) as new_projects_this_week,
                (SELECT COUNT(*) FROM orders) as total_orders,
                (SELECT COUNT(*) FROM orders WHERE status = 'completed') as completed_orders,
                (SELECT COUNT(*) FROM orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)) as new_orders_this_week,
                (SELECT SUM(amount) FROM withdrawals WHERE status = 'completed') as total_withdrawals,
                (SELECT COUNT(*) FROM withdrawals WHERE status = 'pending') as pending_withdrawals,
                (SELECT SUM(amount) FROM orders WHERE status = 'completed') as total_transaction_amount
        `);
        
        // 最近订单
        const [recentOrders] = await pool.query(`
            SELECT o.*, buyer.nickname as buyer_name, seller.nickname as seller_name
            FROM orders o
            LEFT JOIN users buyer ON o.buyer_id = buyer.id
            LEFT JOIN users seller ON o.seller_id = seller.id
            ORDER BY o.created_at DESC
            LIMIT 10
        `);
        
        // 最近注册用户
        const [recentUsers] = await pool.query(`
            SELECT id, phone, nickname, user_type, provider_status, created_at
            FROM users
            ORDER BY created_at DESC
            LIMIT 10
        `);
        
        // 最近的提现申请
        const [recentWithdrawals] = await pool.query(`
            SELECT w.*, u.nickname, u.phone
            FROM withdrawals w
            LEFT JOIN users u ON w.user_id = u.id
            ORDER BY w.created_at DESC
            LIMIT 10
        `);
        
        res.json({
            stats: stats[0],
            recent_orders: recentOrders,
            recent_users: recentUsers,
            recent_withdrawals: recentWithdrawals
        });
    } catch (error) {
        console.error('获取仪表盘错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /users - 获取用户列表
router.get('/users', verifyAdmin, async (req, res) => {
    try {
        const { keyword, user_type, status, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        let where = '1=1';
        const params = [];
        
        if (keyword) {
            where += ' AND (phone LIKE ? OR nickname LIKE ?)';
            params.push(`%${keyword}%`, `%${keyword}%`);
        }
        
        if (user_type) {
            where += ' AND user_type = ?';
            params.push(user_type);
        }
        
        if (status) {
            where += ' AND status = ?';
            params.push(status);
        }
        
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM users WHERE ${where}`, params);
        
        const [rows] = await pool.query(`
            SELECT id, phone, nickname, avatar, user_type, provider_status, status, rating, completed_orders, created_at, last_login_at
            FROM users WHERE ${where}
            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        `, [...params, parseInt(pageSize), offset]);
        
        res.json({
            list: rows,
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取用户列表错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /users/:id - 更新用户状态
router.put('/users/:id', verifyAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const { status, provider_status } = req.body;
        
        const pool = getPool();
        
        let updates = [];
        let params = [];
        
        if (status) {
            updates.push('status = ?');
            params.push(status);
        }
        
        if (provider_status) {
            updates.push('provider_status = ?');
            params.push(provider_status);
            
            if (provider_status === 'approved') {
                updates.push('is_skill_verified = 1');
            } else if (provider_status === 'rejected') {
                updates.push('is_skill_verified = 0');
            }
        }
        
        if (updates.length === 0) {
            return res.status(400).json({ error: '没有需要更新的字段' });
        }
        
        params.push(id);
        
        await pool.query(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, params);
        
        res.json({ message: '用户状态更新成功' });
    } catch (error) {
        console.error('更新用户状态错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /projects - 获取项目列表
router.get('/projects', verifyAdmin, async (req, res) => {
    try {
        const { status, keyword, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        let where = '1=1';
        const params = [];
        
        if (status) {
            where += ' AND p.status = ?';
            params.push(status);
        }
        
        if (keyword) {
            where += ' AND (p.title LIKE ? OR p.description LIKE ?)';
            params.push(`%${keyword}%`, `%${keyword}%`);
        }
        
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM projects p WHERE ${where}`, params);
        
        const [rows] = await pool.query(`
            SELECT p.*, u.nickname as employer_name, c.name as category_name
            FROM projects p
            LEFT JOIN users u ON p.user_id = u.id
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE ${where}
            ORDER BY p.created_at DESC
            LIMIT ? OFFSET ?
        `, [...params, parseInt(pageSize), offset]);
        
        res.json({
            list: rows.map(r => ({ ...r, skills: r.skills ? JSON.parse(r.skills) : [] })),
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取项目列表错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /projects/:id/status - 更新项目状态
router.put('/projects/:id/status', verifyAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        
        if (!['open', 'in_progress', 'completed', 'cancelled', 'closed'].includes(status)) {
            return res.status(400).json({ error: '无效的项目状态' });
        }
        
        const pool = getPool();
        await pool.query('UPDATE projects SET status = ? WHERE id = ?', [status, id]);
        
        res.json({ message: '项目状态更新成功' });
    } catch (error) {
        console.error('更新项目状态错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /orders - 获取订单列表
router.get('/orders', verifyAdmin, async (req, res) => {
    try {
        const { status, keyword, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        let where = '1=1';
        const params = [];
        
        if (status) {
            where += ' AND o.status = ?';
            params.push(status);
        }
        
        if (keyword) {
            where += ' AND (o.order_no LIKE ? OR o.title LIKE ?)';
            params.push(`%${keyword}%`, `%${keyword}%`);
        }
        
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM orders o WHERE ${where}`, params);
        
        const [rows] = await pool.query(`
            SELECT o.*, buyer.nickname as buyer_name, seller.nickname as seller_name
            FROM orders o
            LEFT JOIN users buyer ON o.buyer_id = buyer.id
            LEFT JOIN users seller ON o.seller_id = seller.id
            WHERE ${where}
            ORDER BY o.created_at DESC
            LIMIT ? OFFSET ?
        `, [...params, parseInt(pageSize), offset]);
        
        res.json({
            list: rows,
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取订单列表错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /orders/:id/status - 更新订单状态
router.put('/orders/:id/status', verifyAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        
        const validStatuses = ['pending_payment', 'paid', 'in_progress', 'submitted', 'completed', 'cancelled', 'refunded', 'disputed'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ error: '无效的订单状态' });
        }
        
        const pool = getPool();
        const connection = await pool.getConnection();
        
        try {
            await connection.beginTransaction();
            
            const [orders] = await connection.query('SELECT * FROM orders WHERE id = ?', [id]);
            if (orders.length === 0) {
                await connection.rollback();
                return res.status(404).json({ error: '订单不存在' });
            }
            
            // 处理状态变更逻辑
            if (status === 'completed') {
                await connection.query('UPDATE orders SET status = ?, complete_time = NOW() WHERE id = ?', [status, id]);
                // 执行完成订单的相关操作
                const order = orders[0];
                await connection.query('UPDATE wallets SET balance = balance + ?, total_earnings = total_earnings + ? WHERE user_id = ?', 
                    [order.actual_amount, order.actual_amount, order.seller_id]);
                await connection.query('UPDATE users SET completed_orders = completed_orders + 1 WHERE id = ?', [order.seller_id]);
            } else if (status === 'cancelled') {
                const order = orders[0];
                if (order.status === 'paid') {
                    await connection.query('UPDATE wallets SET balance = balance + ? WHERE user_id = ?', [order.actual_amount, order.buyer_id]);
                }
                await connection.query('UPDATE orders SET status = ? WHERE id = ?', [status, id]);
            } else {
                await connection.query('UPDATE orders SET status = ? WHERE id = ?', [status, id]);
            }
            
            await connection.commit();
            res.json({ message: '订单状态更新成功' });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('更新订单状态错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /finance - 获取财务数据
router.get('/finance', verifyAdmin, async (req, res) => {
    try {
        const { type, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        
        // 总体财务统计
        const [summary] = await pool.query(`
            SELECT 
                (SELECT SUM(balance) FROM wallets) as total_platform_balance,
                (SELECT SUM(frozen_amount) FROM wallets) as total_frozen,
                (SELECT SUM(total_earnings) FROM wallets) as total_earnings,
                (SELECT SUM(amount) FROM withdrawals WHERE status = 'completed') as total_withdrawn,
                (SELECT SUM(amount) FROM orders WHERE status = 'completed') as total_transaction
        `);
        
        // 收支记录
        const offset = (page - 1) * pageSize;
        let where = '1=1';
        const params = [];
        
        if (type === 'withdrawals') {
            where = '1=1';
            const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM withdrawals WHERE ${where}`, params);
            const [rows] = await pool.query(`
                SELECT w.*, u.nickname, u.phone
                FROM withdrawals w
                LEFT JOIN users u ON w.user_id = u.id
                WHERE ${where}
                ORDER BY w.created_at DESC
                LIMIT ? OFFSET ?
            `, [...params, parseInt(pageSize), offset]);
            
            return res.json({
                type: 'withdrawals',
                list: rows,
                total: countResult[0].total,
                summary: summary[0],
                page: parseInt(page),
                pageSize: parseInt(pageSize)
            });
        }
        
        // 钱包流水
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM wallet_transactions`, params);
        const [transactions] = await pool.query(`
            SELECT wt.*, u.nickname, u.phone
            FROM wallet_transactions wt
            LEFT JOIN wallets w ON wt.wallet_id = w.id
            LEFT JOIN users u ON w.user_id = u.id
            ORDER BY wt.created_at DESC
            LIMIT ? OFFSET ?
        `, [parseInt(pageSize), offset]);
        
        res.json({
            type: 'transactions',
            list: transactions,
            total: countResult[0].total,
            summary: summary[0],
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取财务数据错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /withdrawals/:id - 处理提现申请
router.put('/withdrawals/:id', verifyAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const { status, reject_reason } = req.body;
        
        if (!['approved', 'rejected', 'processing', 'completed'].includes(status)) {
            return res.status(400).json({ error: '无效的状态' });
        }
        
        const pool = getPool();
        const connection = await pool.getConnection();
        
        try {
            await connection.beginTransaction();
            
            const [withdrawals] = await connection.query('SELECT * FROM withdrawals WHERE id = ?', [id]);
            if (withdrawals.length === 0) {
                await connection.rollback();
                return res.status(404).json({ error: '提现记录不存在' });
            }
            
            const withdrawal = withdrawals[0];
            
            if (status === 'completed') {
                // 完成提现
                await connection.query(
                    'UPDATE wallets SET frozen_amount = frozen_amount - ?, total_withdrawn = total_withdrawn + ? WHERE user_id = ?',
                    [withdrawal.amount, withdrawal.actual_amount, withdrawal.user_id]
                );
                
                await connection.query(
                    `INSERT INTO wallet_transactions (wallet_id, type, amount, balance_before, balance_after, source, source_id, description)
                     SELECT w.id, 'withdraw', ?, w.balance, w.balance - ?, 'withdraw_complete', ?, '提现成功' FROM wallets w WHERE w.user_id = ?`,
                    [withdrawal.actual_amount, withdrawal.actual_amount, id, withdrawal.user_id]
                );
            } else if (status === 'rejected') {
                // 拒绝提现，解冻金额
                await connection.query(
                    'UPDATE wallets SET balance = balance + ?, frozen_amount = frozen_amount - ? WHERE user_id = ?',
                    [withdrawal.amount, withdrawal.amount, withdrawal.user_id]
                );
                
                await connection.query(
                    `INSERT INTO wallet_transactions (wallet_id, type, amount, balance_before, balance_after, source, source_id, description)
                     SELECT w.id, 'unfrozen', ?, w.balance - ?, w.balance, 'withdraw_rejected', ?, '提现被拒绝，资金解冻' FROM wallets w WHERE w.user_id = ?`,
                    [withdrawal.amount, withdrawal.amount, id, withdrawal.user_id]
                );
            }
            
            await connection.query(
                'UPDATE withdrawals SET status = ?, process_time = NOW(), reject_reason = ? WHERE id = ?',
                [status, reject_reason || null, id]
            );
            
            await connection.commit();
            res.json({ message: '提现处理成功' });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('处理提现错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /announcement - 发布公告
router.post('/announcement', verifyAdmin, async (req, res) => {
    try {
        const { title, content } = req.body;
        
        if (!title || !content) {
            return res.status(400).json({ error: '请填写公告标题和内容' });
        }
        
        const pool = getPool();
        
        // 创建系统消息通知所有用户
        const [users] = await pool.query('SELECT id FROM users');
        
        for (const user of users) {
            await pool.query(
                'INSERT INTO notifications (user_id, type, title, content) VALUES (?, ?, ?, ?)',
                [user.id, 'system_announcement', title, content]
            );
        }
        
        res.json({ message: '公告发布成功', count: users.length });
    } catch (error) {
        console.error('发布公告错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /categories - 获取分类管理
router.get('/categories', verifyAdmin, async (req, res) => {
    try {
        const pool = getPool();
        const [rows] = await pool.query('SELECT * FROM categories ORDER BY sort_order');
        
        res.json({ list: rows });
    } catch (error) {
        console.error('获取分类错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /categories - 创建分类
router.post('/categories', verifyAdmin, async (req, res) => {
    try {
        const { name, icon, parent_id, sort_order } = req.body;
        
        if (!name) {
            return res.status(400).json({ error: '请输入分类名称' });
        }
        
        const pool = getPool();
        const [result] = await pool.query(
            'INSERT INTO categories (name, icon, parent_id, sort_order) VALUES (?, ?, ?, ?)',
            [name, icon, parent_id || 0, sort_order || 0]
        );
        
        res.json({ id: result.insertId, message: '分类创建成功' });
    } catch (error) {
        console.error('创建分类错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /categories/:id - 更新分类
router.put('/categories/:id', verifyAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const { name, icon, parent_id, sort_order, status } = req.body;
        
        const pool = getPool();
        await pool.query(
            'UPDATE categories SET name = ?, icon = ?, parent_id = ?, sort_order = ?, status = ? WHERE id = ?',
            [name, icon, parent_id, sort_order, status, id]
        );
        
        res.json({ message: '分类更新成功' });
    } catch (error) {
        console.error('更新分类错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// DELETE /categories/:id - 删除分类
router.delete('/categories/:id', verifyAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const pool = getPool();
        
        const [children] = await pool.query('SELECT COUNT(*) as c FROM categories WHERE parent_id = ?', [id]);
        if (children[0].c > 0) {
            return res.status(400).json({ error: '请先删除子分类' });
        }
        
        await pool.query('DELETE FROM categories WHERE id = ?', [id]);
        
        res.json({ message: '分类删除成功' });
    } catch (error) {
        console.error('删除分类错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /services - 获取服务列表
router.get('/services', verifyAdmin, async (req, res) => {
    try {
        const { status, keyword, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        let where = '1=1';
        const params = [];
        
        if (status) {
            where += ' AND s.status = ?';
            params.push(status);
        }
        
        if (keyword) {
            where += ' AND (s.title LIKE ? OR s.description LIKE ?)';
            params.push(`%${keyword}%`, `%${keyword}%`);
        }
        
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM services s WHERE ${where}`, params);
        
        const [rows] = await pool.query(`
            SELECT s.*, u.nickname as seller_name, c.name as category_name
            FROM services s
            LEFT JOIN users u ON s.user_id = u.id
            LEFT JOIN categories c ON s.category_id = c.id
            WHERE ${where}
            ORDER BY s.created_at DESC
            LIMIT ? OFFSET ?
        `, [...params, parseInt(pageSize), offset]);
        
        res.json({
            list: rows,
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取服务列表错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /services/:id/status - 更新服务状态
router.put('/services/:id/status', verifyAdmin, async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        
        if (!['active', 'draft', 'paused', 'deleted'].includes(status)) {
            return res.status(400).json({ error: '无效的服务状态' });
        }
        
        const pool = getPool();
        await pool.query('UPDATE services SET status = ? WHERE id = ?', [status, id]);
        
        res.json({ message: '服务状态更新成功' });
    } catch (error) {
        console.error('更新服务状态错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /config - 获取系统配置
router.get('/config', verifyAdmin, async (req, res) => {
    try {
        const pool = getPool();
        const [rows] = await pool.query('SELECT * FROM system_config');
        
        const config = {};
        rows.forEach(row => {
            config[row.config_key] = row.config_value;
        });
        
        res.json({ config });
    } catch (error) {
        console.error('获取配置错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /config - 更新系统配置
router.put('/config', verifyAdmin, async (req, res) => {
    try {
        const { config_key, config_value } = req.body;
        
        const pool = getPool();
        await pool.query(
            'UPDATE system_config SET config_value = ? WHERE config_key = ?',
            [config_value, config_key]
        );
        
        res.json({ message: '配置更新成功' });
    } catch (error) {
        console.error('更新配置错误:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
