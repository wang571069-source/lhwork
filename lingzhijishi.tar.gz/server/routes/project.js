const express = require('express');
const router = express.Router();
const { getPool } = require('../config/database');
const { verifyToken } = require('../middleware/auth');

// GET /list - 获取项目列表
router.get('/list', async (req, res) => {
    try {
        const { category, status, budget_min, budget_max, timeline, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        let where = 'WHERE p.status = ?';
        const params = [status || 'open'];
        
        if (category) {
            where += ' AND p.category_id = ?';
            params.push(category);
        }
        
        if (budget_min) {
            where += ' AND p.budget_max >= ?';
            params.push(parseFloat(budget_min));
        }
        
        if (budget_max) {
            where += ' AND p.budget_min <= ?';
            params.push(parseFloat(budget_max));
        }
        
        if (timeline) {
            where += ' AND p.deadline >= ?';
            params.push(timeline);
        }
        
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM projects p ${where}`, params);
        
        const [rows] = await pool.query(`
            SELECT p.*, u.nickname as employer_name, u.avatar as employer_avatar,
                   c.name as category_name
            FROM projects p
            LEFT JOIN users u ON p.user_id = u.id
            LEFT JOIN categories c ON p.category_id = c.id
            ${where}
            ORDER BY p.created_at DESC
            LIMIT ? OFFSET ?
        `, [...params, parseInt(pageSize), offset]);
        
        res.json({
            list: rows.map(r => ({ ...r, skills: r.skills ? JSON.parse(r.skills) : [] })),
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取项目列表错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /detail/:id - 获取项目详情
router.get('/detail/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const pool = getPool();
        
        const [rows] = await pool.query(`
            SELECT p.*, u.nickname as employer_name, u.avatar as employer_avatar,
                   u.rating as employer_rating, c.name as category_name
            FROM projects p
            LEFT JOIN users u ON p.user_id = u.id
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.id = ?
        `, [id]);
        
        if (rows.length === 0) {
            return res.status(404).json({ error: '项目不存在' });
        }
        
        const project = rows[0];
        project.skills = project.skills ? JSON.parse(project.skills) : [];
        project.attachment_urls = project.attachment_urls ? JSON.parse(project.attachment_urls) : [];
        
        res.json({ project });
    } catch (error) {
        console.error('获取项目详情错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /create - 创建项目
router.post('/create', verifyToken, async (req, res) => {
    try {
        const { title, description, category_id, budget_min, budget_max, deadline, skills, attachment_urls } = req.body;
        
        if (!title || !description) {
            return res.status(400).json({ error: '请填写完整信息' });
        }
        
        const pool = getPool();
        const [result] = await pool.query(
            `INSERT INTO projects (user_id, category_id, title, description, budget_min, budget_max, deadline, skills, attachment_urls)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [req.userId, category_id, title, description, budget_min, budget_max, deadline, 
             JSON.stringify(skills || []), JSON.stringify(attachment_urls || [])]
        );
        
        res.json({ id: result.insertId, message: '项目发布成功' });
    } catch (error) {
        console.error('发布项目错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /update/:id - 更新项目
router.put('/update/:id', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const { title, description, category_id, budget_min, budget_max, deadline, skills, attachment_urls } = req.body;
        
        const pool = getPool();
        
        // 验证所有权
        const [projects] = await pool.query('SELECT user_id, status FROM projects WHERE id = ?', [id]);
        if (projects.length === 0) {
            return res.status(404).json({ error: '项目不存在' });
        }
        
        if (projects[0].user_id !== req.userId) {
            return res.status(403).json({ error: '无权修改此项目' });
        }
        
        if (projects[0].status !== 'open') {
            return res.status(400).json({ error: '只有开放状态的项目才能修改' });
        }
        
        await pool.query(
            `UPDATE projects SET 
             title = ?, description = ?, category_id = ?, budget_min = ?, 
             budget_max = ?, deadline = ?, skills = ?, attachment_urls = ?
             WHERE id = ?`,
            [title, description, category_id, budget_min, budget_max, deadline, 
             JSON.stringify(skills || []), JSON.stringify(attachment_urls || []), id]
        );
        
        res.json({ message: '项目更新成功' });
    } catch (error) {
        console.error('更新项目错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// DELETE /delete/:id - 删除项目
router.delete('/delete/:id', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        
        const pool = getPool();
        
        // 验证所有权
        const [projects] = await pool.query('SELECT user_id, status FROM projects WHERE id = ?', [id]);
        if (projects.length === 0) {
            return res.status(404).json({ error: '项目不存在' });
        }
        
        if (projects[0].user_id !== req.userId) {
            return res.status(403).json({ error: '无权删除此项目' });
        }
        
        if (!['open', 'closed', 'cancelled'].includes(projects[0].status)) {
            return res.status(400).json({ error: '当前状态无法删除' });
        }
        
        await pool.query('DELETE FROM projects WHERE id = ?', [id]);
        
        res.json({ message: '项目删除成功' });
    } catch (error) {
        console.error('删除项目错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /my - 获取我发布的项目
router.get('/my', verifyToken, async (req, res) => {
    try {
        const { status, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        let where = 'WHERE user_id = ?';
        const params = [req.userId];
        
        if (status) {
            where += ' AND status = ?';
            params.push(status);
        }
        
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM projects ${where}`, params);
        
        const [rows] = await pool.query(
            `SELECT * FROM projects ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
            [...params, parseInt(pageSize), offset]
        );
        
        res.json({
            list: rows.map(r => ({ ...r, skills: r.skills ? JSON.parse(r.skills) : [] })),
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取我的项目错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /proposal - 投标项目
router.post('/proposal', verifyToken, async (req, res) => {
    try {
        const { project_id, price, proposal_text, timeline } = req.body;
        
        if (!project_id || !price || !timeline) {
            return res.status(400).json({ error: '请填写完整信息' });
        }
        
        const pool = getPool();
        
        // 检查项目是否存在且开放
        const [projects] = await pool.query('SELECT * FROM projects WHERE id = ? AND status = ?', [project_id, 'open']);
        if (projects.length === 0) {
            return res.status(404).json({ error: '项目不存在或已关闭' });
        }
        
        // 不能投标给自己的项目
        if (projects[0].user_id === req.userId) {
            return res.status(400).json({ error: '不能投标自己的项目' });
        }
        
        // 检查是否已经投过标
        const [existing] = await pool.query('SELECT id FROM proposals WHERE project_id = ? AND user_id = ?', [project_id, req.userId]);
        if (existing.length > 0) {
            return res.status(400).json({ error: '您已经投过此项目' });
        }
        
        const [result] = await pool.query(
            `INSERT INTO proposals (project_id, user_id, price, duration_days, cover_letter) VALUES (?, ?, ?, ?, ?)`,
            [project_id, req.userId, price, timeline, proposal_text]
        );
        
        // 更新项目投标数
        await pool.query('UPDATE projects SET proposals_count = proposals_count + 1 WHERE id = ?', [project_id]);
        
        res.json({ id: result.insertId, message: '投标成功' });
    } catch (error) {
        console.error('投标错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /proposals/:project_id - 获取项目投标列表
router.get('/proposals/:project_id', verifyToken, async (req, res) => {
    try {
        const { project_id } = req.params;
        
        const pool = getPool();
        
        // 验证项目所有权
        const [projects] = await pool.query('SELECT user_id FROM projects WHERE id = ?', [project_id]);
        if (projects.length === 0) {
            return res.status(404).json({ error: '项目不存在' });
        }
        
        // 只有项目发布者可以查看投标
        if (projects[0].user_id !== req.userId) {
            return res.status(403).json({ error: '无权查看此项目的投标' });
        }
        
        const [rows] = await pool.query(`
            SELECT p.*, u.nickname as provider_name, u.avatar as provider_avatar,
                   u.rating as provider_rating, u.completed_orders as provider_completed_orders,
                   u.skills as provider_skills
            FROM proposals p
            LEFT JOIN users u ON p.user_id = u.id
            WHERE p.project_id = ?
            ORDER BY p.created_at DESC
        `, [project_id]);
        
        res.json({ 
            list: rows.map(r => ({ ...r, provider_skills: r.provider_skills ? JSON.parse(r.provider_skills) : [] })) 
        });
    } catch (error) {
        console.error('获取投标列表错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /proposal/:id/accept - 接受投标
router.put('/proposal/:id/accept', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        
        const pool = getPool();
        const connection = await pool.getConnection();
        
        try {
            await connection.beginTransaction();
            
            // 获取投标信息
            const [proposals] = await connection.query('SELECT * FROM proposals WHERE id = ?', [id]);
            if (proposals.length === 0) {
                await connection.rollback();
                return res.status(404).json({ error: '投标不存在' });
            }
            
            const proposal = proposals[0];
            
            // 验证项目所有权
            const [projects] = await connection.query('SELECT * FROM projects WHERE id = ?', [proposal.project_id]);
            if (projects.length === 0 || projects[0].user_id !== req.userId) {
                await connection.rollback();
                return res.status(403).json({ error: '无权操作' });
            }
            
            if (projects[0].status !== 'open') {
                await connection.rollback();
                return res.status(400).json({ error: '项目状态不正确' });
            }
            
            // 更新投标状态
            await connection.query('UPDATE proposals SET status = "accepted" WHERE id = ?', [id]);
            
            // 更新项目状态和分配
            await connection.query('UPDATE projects SET status = "in_progress", assigned_provider_id = ? WHERE id = ?', 
                [proposal.user_id, proposal.project_id]);
            
            // 拒绝其他投标
            await connection.query('UPDATE proposals SET status = "rejected" WHERE project_id = ? AND id != ?', 
                [proposal.project_id, id]);
            
            await connection.commit();
            res.json({ message: '已接受投标' });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('接受投标错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /proposal/:id/reject - 拒绝投标
router.put('/proposal/:id/reject', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        
        const pool = getPool();
        
        // 获取投标信息
        const [proposals] = await pool.query('SELECT * FROM proposals WHERE id = ?', [id]);
        if (proposals.length === 0) {
            return res.status(404).json({ error: '投标不存在' });
        }
        
        const proposal = proposals[0];
        
        // 验证项目所有权
        const [projects] = await pool.query('SELECT user_id FROM projects WHERE id = ?', [proposal.project_id]);
        if (projects.length === 0 || projects[0].user_id !== req.userId) {
            return res.status(403).json({ error: '无权操作' });
        }
        
        await pool.query('UPDATE proposals SET status = "rejected" WHERE id = ?', [id]);
        
        res.json({ message: '已拒绝投标' });
    } catch (error) {
        console.error('拒绝投标错误:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
