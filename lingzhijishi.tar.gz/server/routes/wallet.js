const express = require('express');
const router = express.Router();
const { getPool } = require('../config/database');
const { verifyToken } = require('../middleware/auth');

// GET /info - 获取钱包信息
router.get('/info', verifyToken, async (req, res) => {
    try {
        const pool = getPool();
        const [wallets] = await pool.query(
            'SELECT id, user_id, balance, frozen_amount, total_earnings, total_withdrawn, created_at FROM wallets WHERE user_id = ?', 
            [req.userId]
        );
        
        if (wallets.length === 0) {
            // 创建钱包
            const [result] = await pool.query('INSERT INTO wallets (user_id, balance) VALUES (?, 0)', [req.userId]);
            return res.json({ 
                wallet: { 
                    id: result.insertId, 
                    user_id: req.userId, 
                    balance: 0, 
                    frozen_amount: 0, 
                    total_earnings: 0, 
                    total_withdrawn: 0 
                } 
            });
        }
        
        res.json({ wallet: wallets[0] });
    } catch (error) {
        console.error('获取钱包信息错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /transactions - 获取钱包流水
router.get('/transactions', verifyToken, async (req, res) => {
    try {
        const { type, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        
        const [wallets] = await pool.query('SELECT id FROM wallets WHERE user_id = ?', [req.userId]);
        if (wallets.length === 0) {
            return res.json({ list: [], total: 0, page: 1, pageSize: parseInt(pageSize) });
        }
        
        const walletId = wallets[0].id;
        let where = 'WHERE wallet_id = ?';
        const params = [walletId];
        
        if (type) {
            where += ' AND type = ?';
            params.push(type);
        }
        
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM wallet_transactions ${where}`, params);
        
        const [rows] = await pool.query(
            `SELECT * FROM wallet_transactions ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
            [...params, parseInt(pageSize), offset]
        );
        
        res.json({
            list: rows,
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取流水错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /withdraw - 提现申请
router.post('/withdraw', verifyToken, async (req, res) => {
    try {
        const { amount, bank_name, bank_card } = req.body;
        
        if (!amount || amount < 100) {
            return res.status(400).json({ error: '最低提现金额100元' });
        }
        
        if (!bank_name || !bank_card) {
            return res.status(400).json({ error: '请填写完整的银行信息' });
        }
        
        const pool = getPool();
        const connection = await pool.getConnection();
        
        try {
            await connection.beginTransaction();
            
            const [wallets] = await connection.query('SELECT * FROM wallets WHERE user_id = ?', [req.userId]);
            if (wallets.length === 0) {
                await connection.rollback();
                return res.status(404).json({ error: '钱包不存在' });
            }
            
            const wallet = wallets[0];
            
            if (parseFloat(wallet.balance) < parseFloat(amount)) {
                await connection.rollback();
                return res.status(400).json({ error: '余额不足' });
            }
            
            // 计算手续费
            const fee = parseFloat(amount) * 0.01;
            const actualAmount = parseFloat(amount) - fee;
            
            // 创建提现记录
            const [result] = await connection.query(
                `INSERT INTO withdrawals (user_id, wallet_id, amount, fee, actual_amount, bank_name, bank_account, bank_holder) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [req.userId, wallet.id, amount, fee, actualAmount, bank_name, bank_card, '']
            );
            
            // 冻结金额
            await connection.query(
                'UPDATE wallets SET balance = balance - ?, frozen_amount = frozen_amount + ? WHERE user_id = ?', 
                [amount, amount, req.userId]
            );
            
            // 记录流水
            const [updatedWallet] = await connection.query('SELECT balance FROM wallets WHERE user_id = ?', [req.userId]);
            await connection.query(
                `INSERT INTO wallet_transactions (wallet_id, type, amount, balance_before, balance_after, source, source_id, description) 
                 VALUES (?, 'frozen', ?, ?, ?, 'withdraw', ?, '提现申请冻结')`,
                [wallet.id, amount, wallet.balance, updatedWallet[0].balance, result.insertId]
            );
            
            await connection.commit();
            res.json({ message: '提现申请已提交', withdrawal_id: result.insertId });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('提现申请错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /withdrawals - 获取提现记录
router.get('/withdrawals', verifyToken, async (req, res) => {
    try {
        const { status, page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        let where = 'WHERE user_id = ?';
        const params = [req.userId];
        
        if (status) {
            where += ' AND status = ?';
            params.push(status);
        }
        
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM withdrawals ${where}`, params);
        
        const [rows] = await pool.query(
            `SELECT * FROM withdrawals ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
            [...params, parseInt(pageSize), offset]
        );
        
        res.json({
            list: rows,
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取提现记录错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /recharge - 充值（模拟）
router.post('/recharge', verifyToken, async (req, res) => {
    try {
        const { amount, payment_method = 'alipay' } = req.body;
        
        if (!amount || amount <= 0) {
            return res.status(400).json({ error: '请输入正确的金额' });
        }
        
        const pool = getPool();
        const connection = await pool.getConnection();
        
        try {
            await connection.beginTransaction();
            
            const [wallets] = await connection.query('SELECT * FROM wallets WHERE user_id = ?', [req.userId]);
            if (wallets.length === 0) {
                await connection.rollback();
                return res.status(404).json({ error: '钱包不存在' });
            }
            
            const wallet = wallets[0];
            const balanceBefore = parseFloat(wallet.balance);
            const newBalance = balanceBefore + parseFloat(amount);
            
            await connection.query('UPDATE wallets SET balance = ? WHERE user_id = ?', [newBalance, req.userId]);
            
            await connection.query(
                `INSERT INTO wallet_transactions (wallet_id, type, amount, balance_before, balance_after, source, description) 
                 VALUES (?, 'income', ?, ?, ?, 'platform_recharge', '余额充值')`,
                [wallet.id, amount, balanceBefore, newBalance]
            );
            
            await connection.commit();
            res.json({ message: '充值成功', balance: newBalance });
        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }
    } catch (error) {
        console.error('充值错误:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
