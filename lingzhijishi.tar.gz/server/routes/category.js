const express = require('express');
const router = express.Router();
const { getPool } = require('../config/database');
const { verifyToken } = require('../middleware/auth');

// GET /list - 获取分类列表
router.get('/list', async (req, res) => {
    try {
        const { parent_id = 0 } = req.query;
        
        const pool = getPool();
        const [rows] = await pool.query(
            'SELECT * FROM categories WHERE parent_id = ? AND status = 1 ORDER BY sort_order',
            [parent_id]
        );
        
        res.json({ list: rows });
    } catch (error) {
        console.error('获取分类列表错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /all - 获取所有分类（树形结构）
router.get('/all', async (req, res) => {
    try {
        const pool = getPool();
        const [rows] = await pool.query('SELECT * FROM categories WHERE status = 1 ORDER BY sort_order');
        
        // 构建树形结构
        const tree = [];
        const map = {};
        
        rows.forEach(cat => {
            map[cat.id] = { ...cat, children: [] };
        });
        
        rows.forEach(cat => {
            if (cat.parent_id === 0) {
                tree.push(map[cat.id]);
            } else if (map[cat.parent_id]) {
                map[cat.parent_id].children.push(map[cat.id]);
            }
        });
        
        res.json({ list: tree });
    } catch (error) {
        console.error('获取分类树错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /tree - 获取分类树（别名）
router.get('/tree', async (req, res) => {
    try {
        const pool = getPool();
        const [rows] = await pool.query('SELECT * FROM categories WHERE status = 1 ORDER BY sort_order');
        
        const tree = [];
        const map = {};
        
        rows.forEach(cat => {
            map[cat.id] = { ...cat, children: [] };
        });
        
        rows.forEach(cat => {
            if (cat.parent_id === 0) {
                tree.push(map[cat.id]);
            } else if (map[cat.parent_id]) {
                map[cat.parent_id].children.push(map[cat.id]);
            }
        });
        
        res.json({ list: tree });
    } catch (error) {
        console.error('获取分类树错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /detail/:id - 获取分类详情
router.get('/detail/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const pool = getPool();
        
        const [rows] = await pool.query('SELECT * FROM categories WHERE id = ?', [id]);
        
        if (rows.length === 0) {
            return res.status(404).json({ error: '分类不存在' });
        }
        
        res.json({ category: rows[0] });
    } catch (error) {
        console.error('获取分类详情错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /create - 创建分类
router.post('/create', verifyToken, async (req, res) => {
    try {
        const { name, icon, parent_id, sort_order } = req.body;
        
        if (!name) {
            return res.status(400).json({ error: '请输入分类名称' });
        }
        
        const pool = getPool();
        const [result] = await pool.query(
            'INSERT INTO categories (name, icon, parent_id, sort_order) VALUES (?, ?, ?, ?)',
            [name, icon, parent_id || 0, sort_order || 0]
        );
        
        res.json({ id: result.insertId, message: '分类创建成功' });
    } catch (error) {
        console.error('创建分类错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /update/:id - 更新分类
router.put('/update/:id', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const { name, icon, parent_id, sort_order, status } = req.body;
        
        const pool = getPool();
        await pool.query(
            'UPDATE categories SET name = ?, icon = ?, parent_id = ?, sort_order = ?, status = ? WHERE id = ?',
            [name, icon, parent_id, sort_order, status, id]
        );
        
        res.json({ message: '分类更新成功' });
    } catch (error) {
        console.error('更新分类错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// DELETE /delete/:id - 删除分类
router.delete('/delete/:id', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const pool = getPool();
        
        // 检查是否有子分类
        const [children] = await pool.query('SELECT COUNT(*) as c FROM categories WHERE parent_id = ?', [id]);
        if (children[0].c > 0) {
            return res.status(400).json({ error: '请先删除子分类' });
        }
        
        await pool.query('DELETE FROM categories WHERE id = ?', [id]);
        
        res.json({ message: '分类删除成功' });
    } catch (error) {
        console.error('删除分类错误:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
