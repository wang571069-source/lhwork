const express = require('express');
const router = express.Router();
const { getPool } = require('../config/database');
const { verifyToken } = require('../middleware/auth');

// GET /list - 获取服务列表
router.get('/list', async (req, res) => {
    try {
        const { category, price_min, price_max, rating, page = 1, pageSize = 20, sort = 'created_at', order = 'desc' } = req.query;
        
        const pool = getPool();
        let where = 'WHERE s.status = "active"';
        const params = [];
        
        if (category) {
            where += ' AND s.category_id = ?';
            params.push(category);
        }
        
        if (price_min) {
            where += ' AND s.price_min >= ?';
            params.push(parseFloat(price_min));
        }
        
        if (price_max) {
            where += ' AND s.price_max <= ?';
            params.push(parseFloat(price_max));
        }
        
        if (rating) {
            where += ' AND s.rating >= ?';
            params.push(parseFloat(rating));
        }
        
        const offset = (page - 1) * pageSize;
        const allowedSorts = ['created_at', 'price_min', 'rating', 'order_count'];
        const sortField = allowedSorts.includes(sort) ? sort : 'created_at';
        const sortOrder = order === 'asc' ? 'ASC' : 'DESC';
        
        const [countResult] = await pool.query(`SELECT COUNT(*) as total FROM services s ${where}`, params);
        const total = countResult[0].total;
        
        const [rows] = await pool.query(`
            SELECT s.*, u.nickname as seller_name, u.avatar as seller_avatar, u.rating as seller_rating,
                   c.name as category_name
            FROM services s
            LEFT JOIN users u ON s.user_id = u.id
            LEFT JOIN categories c ON s.category_id = c.id
            ${where}
            ORDER BY s.${sortField} ${sortOrder}
            LIMIT ? OFFSET ?
        `, [...params, parseInt(pageSize), offset]);
        
        const list = rows.map(row => ({
            ...row,
            images: row.images ? JSON.parse(row.images) : []
        }));
        
        res.json({ list, total, page: parseInt(page), pageSize: parseInt(pageSize) });
    } catch (error) {
        console.error('获取服务列表错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /detail/:id - 获取服务详情
router.get('/detail/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const pool = getPool();
        
        const [rows] = await pool.query(`
            SELECT s.*, u.nickname as seller_name, u.avatar as seller_avatar, u.rating as seller_rating,
                   u.completed_orders as seller_completed_orders, u.provider_status, u.bio as seller_bio,
                   u.skills as seller_skills, c.name as category_name
            FROM services s
            LEFT JOIN users u ON s.user_id = u.id
            LEFT JOIN categories c ON s.category_id = c.id
            WHERE s.id = ?
        `, [id]);
        
        if (rows.length === 0) {
            return res.status(404).json({ error: '服务不存在' });
        }
        
        const service = rows[0];
        service.images = service.images ? JSON.parse(service.images) : [];
        
        // 获取套餐
        const [packages] = await pool.query(
            'SELECT * FROM service_packages WHERE service_id = ? ORDER BY sort_order',
            [id]
        );
        service.packages = packages.map(pkg => ({
            ...pkg,
            features: pkg.features ? JSON.parse(pkg.features) : []
        }));
        
        res.json({ service });
    } catch (error) {
        console.error('获取服务详情错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /create - 创建服务
router.post('/create', verifyToken, async (req, res) => {
    try {
        const { category_id, title, description, images, price_min, price_max, delivery_days, revision_count } = req.body;
        
        if (!title) {
            return res.status(400).json({ error: '请填写服务标题' });
        }
        
        const pool = getPool();
        const [result] = await pool.query(
            `INSERT INTO services (user_id, category_id, title, description, images, price_min, price_max, delivery_days, revision_count, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')`,
            [req.userId, category_id, title, description, JSON.stringify(images || []), price_min, price_max, delivery_days || 7, revision_count || 1]
        );
        
        res.json({ id: result.insertId, message: '服务创建成功' });
    } catch (error) {
        console.error('创建服务错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// PUT /update/:id - 更新服务
router.put('/update/:id', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const { category_id, title, description, images, price_min, price_max, delivery_days, revision_count, status } = req.body;
        
        const pool = getPool();
        
        // 验证所有权
        const [rows] = await pool.query('SELECT user_id FROM services WHERE id = ?', [id]);
        if (rows.length === 0 || rows[0].user_id !== req.userId) {
            return res.status(403).json({ error: '无权修改此服务' });
        }
        
        await pool.query(
            `UPDATE services SET 
             category_id = ?, title = ?, description = ?, images = ?, 
             price_min = ?, price_max = ?, delivery_days = ?, revision_count = ?, status = ?
             WHERE id = ?`,
            [category_id, title, description, JSON.stringify(images || []), price_min, price_max, delivery_days, revision_count, status, id]
        );
        
        res.json({ message: '服务更新成功' });
    } catch (error) {
        console.error('更新服务错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// DELETE /delete/:id - 删除服务
router.delete('/delete/:id', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        
        const pool = getPool();
        
        // 验证所有权
        const [rows] = await pool.query('SELECT user_id FROM services WHERE id = ?', [id]);
        if (rows.length === 0 || rows[0].user_id !== req.userId) {
            return res.status(403).json({ error: '无权删除此服务' });
        }
        
        // 软删除
        await pool.query('UPDATE services SET status = "deleted" WHERE id = ?', [id]);
        
        res.json({ message: '服务删除成功' });
    } catch (error) {
        console.error('删除服务错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /provider/:provider_id - 获取服务商的服务
router.get('/provider/:provider_id', async (req, res) => {
    try {
        const { provider_id } = req.params;
        const { page = 1, pageSize = 20 } = req.query;
        
        const pool = getPool();
        const offset = (page - 1) * pageSize;
        
        const [countResult] = await pool.query(
            'SELECT COUNT(*) as total FROM services WHERE user_id = ? AND status = "active"',
            [provider_id]
        );
        
        const [rows] = await pool.query(`
            SELECT s.*, c.name as category_name
            FROM services s
            LEFT JOIN categories c ON s.category_id = c.id
            WHERE s.user_id = ? AND s.status = 'active'
            ORDER BY s.created_at DESC
            LIMIT ? OFFSET ?
        `, [provider_id, parseInt(pageSize), offset]);
        
        res.json({
            list: rows.map(r => ({ ...r, images: r.images ? JSON.parse(r.images) : [] })),
            total: countResult[0].total,
            page: parseInt(page),
            pageSize: parseInt(pageSize)
        });
    } catch (error) {
        console.error('获取服务商服务错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /:id/package - 创建/更新套餐
router.post('/:id/package', verifyToken, async (req, res) => {
    try {
        const { id } = req.params;
        const { package_id, name, description, price, delivery_days, revision_count, features, sort_order } = req.body;
        
        const pool = getPool();
        
        // 验证所有权
        const [rows] = await pool.query('SELECT user_id FROM services WHERE id = ?', [id]);
        if (rows.length === 0 || rows[0].user_id !== req.userId) {
            return res.status(403).json({ error: '无权操作此服务' });
        }
        
        if (package_id) {
            // 更新套餐
            await pool.query(
                `UPDATE service_packages SET 
                 name = ?, description = ?, price = ?, delivery_days = ?, 
                 revision_count = ?, features = ?, sort_order = ? 
                 WHERE id = ? AND service_id = ?`,
                [name, description, price, delivery_days, revision_count, JSON.stringify(features || []), sort_order || 0, package_id, id]
            );
            res.json({ message: '套餐更新成功' });
        } else {
            // 创建套餐
            const [result] = await pool.query(
                `INSERT INTO service_packages (service_id, name, description, price, delivery_days, revision_count, features, sort_order) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [id, name, description, price, delivery_days || 7, revision_count || 1, JSON.stringify(features || []), sort_order || 0]
            );
            res.json({ id: result.insertId, message: '套餐创建成功' });
        }
    } catch (error) {
        console.error('操作套餐错误:', error);
        res.status(500).json({ error: error.message });
    }
});

// DELETE /:id/package/:package_id - 删除套餐
router.delete('/:id/package/:package_id', verifyToken, async (req, res) => {
    try {
        const { id, package_id } = req.params;
        
        const pool = getPool();
        
        // 验证所有权
        const [rows] = await pool.query('SELECT user_id FROM services WHERE id = ?', [id]);
        if (rows.length === 0 || rows[0].user_id !== req.userId) {
            return res.status(403).json({ error: '无权操作此服务' });
        }
        
        await pool.query('DELETE FROM service_packages WHERE id = ? AND service_id = ?', [package_id, id]);
        
        res.json({ message: '套餐删除成功' });
    } catch (error) {
        console.error('删除套餐错误:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
