-- 灵职集市数据库结构
-- LingHuoZhi Freelance Marketplace

CREATE DATABASE IF NOT EXISTS lingzhijishi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE lingzhijishi;

-- 1. 用户表
CREATE TABLE IF NOT EXISTS users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL COMMENT '用户名',
    phone VARCHAR(20) UNIQUE NOT NULL COMMENT '手机号',
    password_hash VARCHAR(255) NOT NULL COMMENT '密码哈希',
    nickname VARCHAR(50) COMMENT '昵称',
    avatar VARCHAR(500) COMMENT '头像URL',
    role ENUM('employer', 'freelancer', 'admin') DEFAULT 'freelancer' COMMENT '角色',
    email VARCHAR(100) COMMENT '邮箱',
    status ENUM('active', 'disabled', 'banned') DEFAULT 'active' COMMENT '状态',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_phone (phone),
    INDEX idx_username (username),
    INDEX idx_role (role),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 2. 用户资料表
CREATE TABLE IF NOT EXISTS user_profiles (
    user_id BIGINT PRIMARY KEY COMMENT '用户ID',
    real_name VARCHAR(50) COMMENT '真实姓名',
    id_card VARCHAR(20) COMMENT '身份证号',
    id_card_front VARCHAR(500) COMMENT '身份证正面照',
    id_card_back VARCHAR(500) COMMENT '身份证背面照',
    gender ENUM('male', 'female', 'unknown') DEFAULT 'unknown' COMMENT '性别',
    birthday DATE COMMENT '生日',
    province VARCHAR(50) COMMENT '省份',
    city VARCHAR(50) COMMENT '城市',
    bio TEXT COMMENT '个人简介',
    skills JSON COMMENT '技能标签列表',
    rating DECIMAL(3,2) DEFAULT 5.00 COMMENT '评分',
    rating_count INT DEFAULT 0 COMMENT '评价次数',
    total_earnings DECIMAL(15,2) DEFAULT 0 COMMENT '累计收入',
    verified_at TIMESTAMP NULL COMMENT '认证时间',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_province_city (province, city)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户资料表';

-- 3. 分类表
CREATE TABLE IF NOT EXISTS categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL COMMENT '分类名称',
    icon VARCHAR(100) COMMENT '图标',
    parent_id INT DEFAULT 0 COMMENT '父分类ID',
    sort_order INT DEFAULT 0 COMMENT '排序',
    status TINYINT(1) DEFAULT 1 COMMENT '状态:0禁用1启用',
    INDEX idx_parent (parent_id),
    INDEX idx_sort (sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='分类表';

-- 4. 项目表
CREATE TABLE IF NOT EXISTS projects (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    employer_id BIGINT NOT NULL COMMENT '雇主ID',
    title VARCHAR(200) NOT NULL COMMENT '项目标题',
    description TEXT COMMENT '项目描述',
    category_id INT COMMENT '分类ID',
    budget_min DECIMAL(10,2) COMMENT '预算最低',
    budget_max DECIMAL(10,2) COMMENT '预算最高',
    timeline INT COMMENT '工期(天)',
    status ENUM('open', 'in_progress', 'completed', 'closed', 'cancelled') DEFAULT 'open' COMMENT '状态',
    view_count INT DEFAULT 0 COMMENT '浏览次数',
    proposal_count INT DEFAULT 0 COMMENT '投标数',
    deadline DATETIME COMMENT '截止日期',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (employer_id) REFERENCES users(id),
    FOREIGN KEY (category_id) REFERENCES categories(id),
    INDEX idx_employer (employer_id),
    INDEX idx_category (category_id),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='项目表';

-- 5. 项目投标表
CREATE TABLE IF NOT EXISTS project_proposals (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    project_id BIGINT NOT NULL COMMENT '项目ID',
    freelancer_id BIGINT NOT NULL COMMENT ' freelancer ID',
    price DECIMAL(10,2) NOT NULL COMMENT '报价',
    proposal_text TEXT COMMENT '投标说明',
    timeline INT COMMENT '工期(天)',
    status ENUM('pending', 'accepted', 'rejected', 'withdrawn') DEFAULT 'pending' COMMENT '状态',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id),
    FOREIGN KEY (freelancer_id) REFERENCES users(id),
    INDEX idx_project (project_id),
    INDEX idx_freelancer (freelancer_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='项目投标表';

-- 6. 服务表
CREATE TABLE IF NOT EXISTS services (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    provider_id BIGINT NOT NULL COMMENT '服务商ID',
    title VARCHAR(200) NOT NULL COMMENT '服务标题',
    description TEXT COMMENT '服务描述',
    category_id INT COMMENT '分类ID',
    price_min DECIMAL(10,2) COMMENT '最低价格',
    price_max DECIMAL(10,2) COMMENT '最高价格',
    images JSON COMMENT '服务图片列表',
    tags JSON COMMENT '标签列表',
    rating DECIMAL(3,2) DEFAULT 5.00 COMMENT '评分',
    rating_count INT DEFAULT 0 COMMENT '评价数',
    sales_count INT DEFAULT 0 COMMENT '销量',
    status ENUM('active', 'draft', 'paused', 'deleted') DEFAULT 'draft' COMMENT '状态',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (provider_id) REFERENCES users(id),
    FOREIGN KEY (category_id) REFERENCES categories(id),
    INDEX idx_provider (provider_id),
    INDEX idx_category (category_id),
    INDEX idx_status (status),
    FULLTEXT idx_title_desc (title, description)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='服务表';

-- 7. 服务套餐表
CREATE TABLE IF NOT EXISTS service_packages (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    service_id BIGINT NOT NULL COMMENT '服务ID',
    name VARCHAR(100) NOT NULL COMMENT '套餐名称',
    description TEXT COMMENT '套餐描述',
    price DECIMAL(10,2) NOT NULL COMMENT '价格',
    delivery_days INT DEFAULT 7 COMMENT '交付天数',
    revision_count INT DEFAULT 1 COMMENT '修改次数',
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE,
    INDEX idx_service (service_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='服务套餐表';

-- 8. 订单表
CREATE TABLE IF NOT EXISTS orders (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    project_id BIGINT COMMENT '项目ID',
    proposal_id BIGINT COMMENT '投标ID',
    employer_id BIGINT NOT NULL COMMENT '雇主ID',
    provider_id BIGINT NOT NULL COMMENT '服务商ID',
    amount DECIMAL(10,2) NOT NULL COMMENT '订单金额',
    platform_fee DECIMAL(10,2) DEFAULT 0 COMMENT '平台费',
    provider_earning DECIMAL(10,2) DEFAULT 0 COMMENT '服务商收入',
    status ENUM('pending', 'paid', 'in_progress', 'completed', 'cancelled', 'refunded') DEFAULT 'pending' COMMENT '状态',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    paid_at TIMESTAMP NULL COMMENT '支付时间',
    completed_at TIMESTAMP NULL COMMENT '完成时间',
    FOREIGN KEY (project_id) REFERENCES projects(id),
    FOREIGN KEY (proposal_id) REFERENCES project_proposals(id),
    FOREIGN KEY (employer_id) REFERENCES users(id),
    FOREIGN KEY (provider_id) REFERENCES users(id),
    INDEX idx_employer (employer_id),
    INDEX idx_provider (provider_id),
    INDEX idx_status (status),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

-- 9. 钱包表
CREATE TABLE IF NOT EXISTS wallets (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT UNIQUE NOT NULL COMMENT '用户ID',
    balance DECIMAL(15,2) DEFAULT 0 COMMENT '余额',
    frozen_balance DECIMAL(15,2) DEFAULT 0 COMMENT '冻结金额',
    total_earnings DECIMAL(15,2) DEFAULT 0 COMMENT '累计收入',
    total_withdrawn DECIMAL(15,2) DEFAULT 0 COMMENT '累计提现',
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='钱包表';

-- 10. 钱包流水表
CREATE TABLE IF NOT EXISTS wallet_transactions (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    wallet_id BIGINT NOT NULL COMMENT '钱包ID',
    type ENUM('income', 'expense', 'withdraw', 'refund', 'frozen', 'unfrozen') NOT NULL COMMENT '类型',
    amount DECIMAL(10,2) NOT NULL COMMENT '金额',
    balance_before DECIMAL(15,2) COMMENT '变动前余额',
    balance_after DECIMAL(15,2) COMMENT '变动后余额',
    description VARCHAR(500) COMMENT '描述',
    order_id BIGINT COMMENT '关联订单ID',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (wallet_id) REFERENCES wallets(id),
    INDEX idx_wallet (wallet_id),
    INDEX idx_type (type),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='钱包流水表';

-- 11. 提现表
CREATE TABLE IF NOT EXISTS withdrawals (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL COMMENT '用户ID',
    amount DECIMAL(10,2) NOT NULL COMMENT '提现金额',
    bank_name VARCHAR(100) COMMENT '银行名称',
    bank_card VARCHAR(50) COMMENT '银行卡号',
    status ENUM('pending', 'approved', 'rejected', 'completed') DEFAULT 'pending' COMMENT '状态',
    processed_at TIMESTAMP NULL COMMENT '处理时间',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_user (user_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='提现表';

-- 12. 消息表
CREATE TABLE IF NOT EXISTS messages (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    from_user_id BIGINT NOT NULL COMMENT '发送者ID',
    to_user_id BIGINT NOT NULL COMMENT '接收者ID',
    project_id BIGINT COMMENT '关联项目ID',
    content TEXT NOT NULL COMMENT '消息内容',
    read_at TIMESTAMP NULL COMMENT '阅读时间',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (from_user_id) REFERENCES users(id),
    FOREIGN KEY (to_user_id) REFERENCES users(id),
    FOREIGN KEY (project_id) REFERENCES projects(id),
    INDEX idx_from_user (from_user_id),
    INDEX idx_to_user (to_user_id),
    INDEX idx_project (project_id),
    INDEX idx_unread (to_user_id, read_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消息表';

-- 13. 通知表
CREATE TABLE IF NOT EXISTS notifications (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    user_id BIGINT NOT NULL COMMENT '用户ID',
    type VARCHAR(50) NOT NULL COMMENT '通知类型',
    title VARCHAR(200) NOT NULL COMMENT '标题',
    content TEXT COMMENT '内容',
    read_at TIMESTAMP NULL COMMENT '阅读时间',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX idx_user (user_id),
    INDEX idx_unread (user_id, read_at),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='通知表';

-- 14. 评价表
CREATE TABLE IF NOT EXISTS reviews (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    order_id BIGINT NOT NULL COMMENT '订单ID',
    project_id BIGINT COMMENT '项目ID',
    reviewer_id BIGINT NOT NULL COMMENT '评价者ID',
    reviewee_id BIGINT NOT NULL COMMENT '被评价者ID',
    rating TINYINT NOT NULL COMMENT '评分1-5',
    content TEXT COMMENT '评价内容',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (project_id) REFERENCES projects(id),
    FOREIGN KEY (reviewer_id) REFERENCES users(id),
    FOREIGN KEY (reviewee_id) REFERENCES users(id),
    INDEX idx_order (order_id),
    INDEX idx_project (project_id),
    INDEX idx_reviewer (reviewer_id),
    INDEX idx_reviewee (reviewee_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='评价表';

-- 15. 管理员表
CREATE TABLE IF NOT EXISTS admin_users (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL COMMENT '用户名',
    password_hash VARCHAR(255) NOT NULL COMMENT '密码哈希',
    nickname VARCHAR(50) COMMENT '昵称',
    role VARCHAR(20) DEFAULT 'admin' COMMENT '角色',
    status ENUM('active', 'disabled') DEFAULT 'active' COMMENT '状态',
    INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员表';
