#!/bin/bash
# 灵职集市 - 一键启动脚本
# 使用方式: ./start.sh

set -e

PROJECT_NAME="灵职集市"
PROJECT_DIR="/home/allen/www/lingzhijishi"
PM2_NAME="lingzhijishi"

YELLOW='\033[1;33m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}   $PROJECT_NAME 一键启动${NC}"
echo -e "${YELLOW}========================================${NC}"
echo ""

# 检查服务是否已运行
RUNNING=$(/home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 jlist 2>/dev/null | grep -c "\"name\":\"$PM2_NAME\"" || echo "0")

if [ "$RUNNING" -gt 0 ]; then
    STATUS=$(/home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 jlist 2>/dev/null | grep "\"name\":\"$PM2_NAME\"" | grep -o '"status":"[^"]*"' | cut -d'"' -f4)
    if [ "$STATUS" = "online" ]; then
        echo -e "${GREEN}✅ $PROJECT_NAME 已经在运行中${NC}"
        /home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 status "$PM2_NAME"
        exit 0
    fi
fi

# 启动服务
echo -e "${YELLOW}[1/2] 启动 $PROJECT_NAME 服务...${NC}"
cd "$PROJECT_DIR/server"

# 检查ecosystem.config.js是否存在
if [ -f "ecosystem.config.js" ]; then
    /home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 start ecosystem.config.js
else
    # 如果没有ecosystem.config.js，手动启动
    /home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 start app.js --name "$PM2_NAME"
fi

# 等待服务启动
sleep 3

echo -e "${YELLOW}[2/2] 验证服务状态...${NC}"

# 检查服务是否在线
ONLINE=$(/home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 jlist 2>/dev/null | grep "\"name\":\"$PM2_NAME\"" | grep -c '"status":"online"' || echo "0")

if [ "$ONLINE" -gt 0 ]; then
    echo ""
    echo -e "${GREEN}========================================${NC}"
    echo -e "${GREEN}   ✅ $PROJECT_NAME 启动成功！${NC}"
    echo -e "${GREEN}========================================${NC}"
    /home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 status "$PM2_NAME"
    echo ""
    echo -e "${GREEN}访问地址: http://localhost/${NC}"
else
    echo -e "${RED}❌ $PROJECT_NAME 启动失败${NC}"
    echo "查看日志: pm2 logs $PM2_NAME"
    exit 1
fi
