#!/bin/bash
# 灵职集市 - 一键启动脚本 v2.0
# 使用方式: ./start.sh
#
# 功能：
#   1. 检查服务是否已运行
#   2. 启动/重启PM2服务
#   3. 验证服务状态

set -e

PROJECT_NAME="灵职集市"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
PM2_NAME="lingzhijishi"

# 颜色定义
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

# 动态查找PM2路径
find_pm2() {
    if [ -x "/home/allen/.hermes/node/bin/pm2" ]; then
        echo "/home/allen/.hermes/node/bin/pm2"
    elif command -v pm2 &> /dev/null; then
        command -v pm2
    else
        echo "pm2"
    fi
}
PM2=$(find_pm2)

# 打印函数
print_step() {
    echo -e "${BLUE}[$1] $2${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warn() {
    echo -e "${YELLOW}⚠️ $1${NC}"
}

# ==========================================
# 检查服务状态
# ==========================================
check_status() {
    echo ""
    echo -e "${YELLOW}========================================${NC}"
    echo -e "${YELLOW}   $PROJECT_NAME 启动脚本 v2.0${NC}"
    echo -e "${YELLOW}========================================${NC}"
    echo ""

    # 检查服务是否已运行
    RUNNING=$($PM2 jlist 2>/dev/null | grep -c "\"name\":\"$PM2_NAME\"" || echo "0")

    if [ "$RUNNING" -gt 0 ]; then
        STATUS=$($PM2 jlist 2>/dev/null | grep "\"name\":\"$PM2_NAME\"" | grep -o '\"status\":\"[^\"]*\"' | cut -d'"' -f4)
        if [ "$STATUS" = "online" ]; then
            print_success "$PROJECT_NAME 已在运行中"
            $PM2 status "$PM2_NAME"
            exit 0
        fi
    fi
}

# ==========================================
# 启动服务
# ==========================================
start_service() {
    print_step "1/2" "启动 $PROJECT_NAME 服务..."

    # 检查目录
    if [ ! -d "$PROJECT_DIR/server" ]; then
        print_error "服务端目录不存在: $PROJECT_DIR/server"
        exit 1
    fi

    cd "$PROJECT_DIR/server"

    # 检查ecosystem.config.js
    if [ -f "ecosystem.config.js" ]; then
        $PM2 start ecosystem.config.js 2>/dev/null || $PM2 restart "$PM2_NAME" --update-env
    else
        print_warn "ecosystem.config.js 不存在，使用默认配置启动"
        $PM2 start app.js --name "$PM2_NAME"
    fi

    # 等待服务启动
    sleep 3
}

# ==========================================
# 验证服务
# ==========================================
verify_service() {
    print_step "2/2" "验证服务状态..."

    ONLINE=$($PM2 jlist 2>/dev/null | grep "\"name\":\"$PM2_NAME\"" | grep -c '\"status\":\"online\"' || echo "0")

    if [ "$ONLINE" -gt 0 ]; then
        echo ""
        echo -e "${GREEN}========================================${NC}"
        echo -e "${GREEN}   ✅ $PROJECT_NAME 启动成功！${NC}"
        echo -e "${GREEN}========================================${NC}"
        $PM2 status "$PM2_NAME"
        echo ""
        print_success "访问地址: http://localhost/"
        print_success "API地址:  http://localhost/api/home"
    else
        print_error "$PROJECT_NAME 启动失败"
        echo ""
        echo "查看日志: $PM2 logs $PM2_NAME"
        exit 1
    fi
}

# ==========================================
# 主流程
# ==========================================
main() {
    check_status
    start_service
    verify_service
}

main "$@"
