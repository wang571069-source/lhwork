#!/bin/bash
# 灵职集市 - 一键停止脚本
# 使用方式: ./stop.sh

set -e

PROJECT_NAME="灵职集市"
PM2_NAME="lingzhijishi"

YELLOW='\033[1;33m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}   $PROJECT_NAME 一键停止${NC}"
echo -e "${YELLOW}========================================${NC}"
echo ""

# 检查服务是否存在
RUNNING=$(/home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 jlist 2>/dev/null | grep -c "\"name\":\"$PM2_NAME\"" || echo "0")

if [ "$RUNNING" -eq 0 ]; then
    echo -e "${GREEN}✅ $PROJECT_NAME 未在运行${NC}"
    exit 0
fi

# 停止服务
echo -e "${YELLOW}[1/2] 停止 $PM2_NAME 服务...${NC}"
/home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 stop "$PM2_NAME" 2>/dev/null || true

echo -e "${YELLOW}[2/2] 删除PM2进程记录...${NC}"
/home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 delete "$PM2_NAME" 2>/dev/null || true

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}   ✅ $PROJECT_NAME 已停止${NC}"
echo -e "${GREEN}========================================${NC}"
/home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 list
