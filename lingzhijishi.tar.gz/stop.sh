#!/bin/bash
# 灵职集市 - 一键停止脚本
# 使用方式: ./stop.sh
#
# 功能：
#   1. 停止PM2服务
#   2. 验证服务已停止

set -e

PROJECT_NAME="灵职集市"
PM2_NAME="lingzhijishi"

# 颜色定义
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

# 动态查找PM2路径
find_pm2() {
    if [ -x "/home/allen/.hermes/node/bin/pm2" ]; then
        echo "/home/allen/.hermes/node/bin/pm2"
    elif command -v pm2 &> /dev/null; then
        command -v pm2
    else
        echo "pm2"
    fi
}
PM2=$(find_pm2)

# 打印函数
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

# ==========================================
# 停止服务
# ==========================================
echo ""
echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}   $PROJECT_NAME 停止脚本${NC}"
echo -e "${YELLOW}========================================${NC}"
echo ""

# 检查服务是否在运行
RUNNING=$($PM2 jlist 2>/dev/null | grep -c "\"name\":\"$PM2_NAME\"" || echo "0")

if [ "$RUNNING" -eq 0 ]; then
    print_success "$PROJECT_NAME 未在运行"
    exit 0
fi

# 停止服务
echo "停止 $PROJECT_NAME 服务..."
$PM2 stop "$PM2_NAME"

# 验证
sleep 1
STOPPED=$($PM2 jlist 2>/dev/null | grep "\"name\":\"$PM2_NAME\"" | grep -c '\"status\":\"stopped\"' || echo "0")

if [ "$STOPPED" -gt 0 ]; then
    echo ""
    print_success "$PROJECT_NAME 已停止"
    $PM2 status "$PM2_NAME"
else
    print_error "$PROJECT_NAME 停止失败"
    exit 1
fi
