#!/bin/bash
# 灵职集市 - 一键部署脚本
# 使用方式: ./deploy.sh

set -e

PROJECT_NAME="灵职集市"
PROJECT_DIR="/home/allen/www/lingzhijishi"
WEB_DIR="/var/www/lingzhijishi"
PM2_NAME="lingzhijishi"

YELLOW='\033[1;33m'
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}   $PROJECT_NAME 一键部署脚本${NC}"
echo -e "${YELLOW}========================================${NC}"
echo ""

# 1. 检查是否为root权限（需要sudo来操作/var/www）
if [ "$(id -u)" -ne 0 ]; then
    echo -e "${RED}错误: 需要root权限来部署Web文件${NC}"
    echo "请使用: sudo ./deploy.sh"
    exit 1
fi

# 2. 检查源代码目录
if [ ! -d "$PROJECT_DIR/server" ]; then
    echo -e "${RED}错误: 源代码目录不存在: $PROJECT_DIR/server${NC}"
    exit 1
fi

# 3. 同步前端文件到Web目录
echo -e "${YELLOW}[1/4] 同步前端文件到Web目录...${NC}"
cp -f "$PROJECT_DIR/frontend/index.html" "$WEB_DIR/index.html"
cp -f "$PROJECT_DIR/frontend/admin.html" "$WEB_DIR/admin.html"
echo -e "${GREEN}✅ 前端文件同步完成${NC}"

# 4. 安装依赖（如果需要）
if [ ! -d "$PROJECT_DIR/server/node_modules" ]; then
    echo -e "${YELLOW}[2/4] 安装Node.js依赖...${NC}"
    cd "$PROJECT_DIR/server" && npm install
    echo -e "${GREEN}✅ 依赖安装完成${NC}"
else
    echo -e "${YELLOW}[2/4] 依赖已存在，跳过安装${NC}"
fi

# 5. 重启PM2服务
echo -e "${YELLOW}[3/4] 重启PM2服务...${NC}"
cd "$PROJECT_DIR/server"
/home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 restart "$PM2_NAME" --update-env 2>/dev/null || \
    /home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 start ecosystem.config.js --update-env
echo -e "${GREEN}✅ PM2服务重启完成${NC}"

# 6. 保存PM2状态
echo -e "${YELLOW}[4/4] 保存PM2状态...${NC}"
/home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 save
echo -e "${GREEN}✅ PM2状态已保存${NC}"

# 7. 验证服务状态
sleep 2
echo ""
echo -e "${YELLOW}========================================${NC}"
echo -e "${YELLOW}   部署完成 - 服务状态${NC}"
echo -e "${YELLOW}========================================${NC}"
/home/allen/.hermes/node/lib/node_modules/pm2/bin/pm2 status "$PM2_NAME"
echo ""
echo -e "${GREEN}✅ 部署成功！${NC}"
echo -e "${GREEN}   访问地址: http://localhost/${NC}"
echo -e "${GREEN}   API地址: http://localhost/api/home/data${NC}"
