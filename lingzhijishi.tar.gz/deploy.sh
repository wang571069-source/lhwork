#!/bin/bash
# 灵职集市 - 一键部署脚本 v2.0
# 使用方式: sudo ./deploy.sh
#
# 功能：
#   1. 检查服务器环境（Node.js、npm、MySQL、Nginx）
#   2. 同步前端文件到Web目录
#   3. 安装/更新Node.js依赖
#   4. 导入数据库（首次部署）
#   5. 重启PM2服务
#   6. 验证服务状态

set -e

PROJECT_NAME="灵职集市"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
WEB_DIR="/var/www/lingzhijishi"
PM2_NAME="lingzhijishi"
DB_NAME="lingzhijishi"

# 颜色定义
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

# 动态查找PM2路径
find_pm2() {
    if [ -x "/home/allen/.hermes/node/bin/pm2" ]; then
        echo "/home/allen/.hermes/node/bin/pm2"
    elif command -v pm2 &> /dev/null; then
        command -v pm2
    elif [ -x "$HOME/.nvm/versions/node/$(node -v)/bin/pm2" ]; then
        echo "$HOME/.nvm/versions/node/$(node -v)/bin/pm2"
    else
        echo "pm2"
    fi
}
PM2=$(find_pm2)

# ==========================================
# 打印函数
# ==========================================
print_header() {
    echo ""
    echo -e "${YELLOW}========================================${NC}"
    echo -e "${YELLOW}   $1${NC}"
    echo -e "${YELLOW}========================================${NC}"
}

print_step() {
    echo -e "${BLUE}[$1/${TOTAL}] $2${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warn() {
    echo -e "${YELLOW}⚠️ $1${NC}"
}

TOTAL=6

# ==========================================
# 检查环境
# ==========================================
check_env() {
    print_header "步骤1: 检查服务器环境"

    # 检查是否为root
    if [ "$(id -u)" -ne 0 ]; then
        print_error "需要root权限来部署Web文件和配置服务"
        echo "请使用: sudo ./deploy.sh"
        exit 1
    fi

    # Node.js
    if command -v node &> /dev/null; then
        NODE_VERSION=$(node -v)
        print_success "Node.js: $NODE_VERSION"
    else
        print_error "Node.js 未安装"
        echo "安装命令: curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - && sudo apt-get install -y nodejs"
        exit 1
    fi

    # npm
    if command -v npm &> /dev/null; then
        NPM_VERSION=$(npm -v)
        print_success "npm: $NPM_VERSION"
    else
        print_error "npm 未安装"
        exit 1
    fi

    # PM2
    if $PM2 --version &> /dev/null; then
        PM2_VERSION=$($PM2 --version)
        print_success "PM2: $PM2_VERSION"
    else
        print_warn "PM2 未安装，正在安装..."
        npm install -g pm2
        print_success "PM2 安装完成"
    fi

    # Nginx
    if command -v nginx &> /dev/null; then
        NGINX_VERSION=$(nginx -v 2>&1 | cut -d' ' -f2)
        print_success "Nginx: $NGINX_VERSION"
    else
        print_error "Nginx 未安装"
        echo "安装命令: sudo apt install nginx"
        exit 1
    fi

    # MySQL
    if command -v mysql &> /dev/null; then
        MYSQL_VERSION=$(mysql --version | awk '{print $5}' | tr -d ',')
        print_success "MySQL: $MYSQL_VERSION"
    else
        print_error "MySQL 未安装"
        echo "安装命令: sudo apt install mysql-server mysql-client"
        exit 1
    fi

    # 检查源代码目录
    if [ ! -d "$PROJECT_DIR/server" ]; then
        print_error "源代码目录不存在: $PROJECT_DIR/server"
        exit 1
    fi
    print_success "项目目录: $PROJECT_DIR"
}

# ==========================================
# 同步前端文件
# ==========================================
sync_frontend() {
    print_header "步骤2: 同步前端文件"

    # 确保Web目录存在
    if [ ! -d "$WEB_DIR" ]; then
        print_warn "Web目录不存在，创建中..."
        mkdir -p "$WEB_DIR"
    fi

    # 同步前端文件
    cp -f "$PROJECT_DIR/frontend/index.html" "$WEB_DIR/index.html"
    cp -f "$PROJECT_DIR/frontend/admin.html" "$WEB_DIR/admin.html" 2>/dev/null || true
    print_success "前端文件已同步到 $WEB_DIR"
}

# ==========================================
# 安装依赖
# ==========================================
install_deps() {
    print_header "步骤3: 安装Node.js依赖"

    cd "$PROJECT_DIR/server"

    # 检查是否需要安装
    if [ -d "node_modules" ]; then
        print_success "依赖已存在"
        # 可选：更新依赖
        # npm update
    else
        print_step "3.1" "安装依赖..."
        npm install
        print_success "依赖安装完成"
    fi

    # 检查关键依赖
    for pkg in express mysql2 bcryptjs jsonwebtoken cors dotenv; do
        if [ -d "node_modules/$pkg" ]; then
            print_success "$pkg"
        else
            print_error "$pkg 缺失"
            exit 1
        fi
    done
}

# ==========================================
# 初始化数据库
# ==========================================
init_db() {
    print_header "步骤4: 初始化数据库"

    # 加载环境变量
    if [ -f "$PROJECT_DIR/server/.env" ]; then
        export $(grep -v '^#' "$PROJECT_DIR/server/.env" | xargs)
    fi

    DB_HOST=${DB_HOST:-localhost}
    DB_PORT=${DB_PORT:-3306}
    DB_USER=${DB_USER:-debian-sys-maint}
    DB_NAME=${DB_NAME:-lingzhijishi}

    # 检查数据库是否存在
    print_step "4.1" "检查数据库..."
    if mysql -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -p"$(grep DB_PASSWORD "$PROJECT_DIR/server/.env" | cut -d'=' -f2)" -e "USE $DB_NAME;" 2>/dev/null; then
        print_success "数据库 $DB_NAME 已存在"
        # 询问是否导入数据
        read -p "是否重新导入数据库？(y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            print_step "4.2" "重新导入数据库..."
            mysql -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -p"$(grep DB_PASSWORD "$PROJECT_DIR/server/.env" | cut -d'=' -f2)" < "$PROJECT_DIR/server/schema.sql"
            print_success "数据库已重新导入"
        fi
    else
        print_warn "数据库 $DB_NAME 不存在，正在创建..."
        print_step "4.2" "导入数据库..."
        mysql -h "$DB_HOST" -P "$DB_PORT" -u "$DB_USER" -p"$(grep DB_PASSWORD "$PROJECT_DIR/server/.env" | cut -d'=' -f2)" < "$PROJECT_DIR/server/schema.sql"
        print_success "数据库创建并导入完成"
    fi
}

# ==========================================
# 重启PM2服务
# ==========================================
restart_pm2() {
    print_header "步骤5: 重启PM2服务"

    cd "$PROJECT_DIR/server"

    # 检查ecosystem.config.js
    if [ ! -f "ecosystem.config.js" ]; then
        print_error "ecosystem.config.js 不存在"
        exit 1
    fi

    # 重启服务
    print_step "5.1" "重启PM2服务..."
    if $PM2 list | grep -q "\"name\":\"$PM2_NAME\""; then
        $PM2 restart "$PM2_NAME" --update-env
        print_success "PM2服务已重启"
    else
        $PM2 start ecosystem.config.js
        print_success "PM2服务已启动"
    fi

    # 等待服务启动
    sleep 3

    # 检查状态
    if $PM2 list | grep -q "\"status\":\"online\""; then
        print_success "服务运行中"
    else
        print_error "服务启动失败，查看日志:"
        $PM2 logs "$PM2_NAME" --lines 20
        exit 1
    fi
}

# ==========================================
# 保存PM2状态
# ==========================================
save_pm2() {
    print_header "步骤6: 配置PM2开机自启"

    print_step "6.1" "保存PM2进程列表..."
    $PM2 save
    print_success "进程列表已保存"

    print_step "6.2" "配置开机自启..."
    if systemctl is-enabled pm2-allen &> /dev/null; then
        print_success "PM2开机自启已配置"
    else
        $PM2 startup systemd -u $(whoami) --hp $HOME 2>/dev/null || \
        env PATH=$PATH:$HOME/.nvm/versions/node/$(node -v)/bin $PM2 startup systemd -u $(whoami) --hp $HOME 2>/dev/null || \
        print_warn "请手动运行: sudo env PATH=\$PATH:\$HOME/.nvm/versions/node/\$(node -v)/bin \$PM2 startup systemd -u \$USER --hp \$HOME"
    fi
}

# ==========================================
# 验证部署
# ==========================================
verify() {
    print_header "部署验证"

    sleep 2

    # 检查端口
    print_step "验证" "检查端口占用..."
    if ss -tlnp 2>/dev/null | grep -q ':3000'; then
        print_success "端口3000 (API) 已监听"
    else
        print_error "端口3000未监听，服务可能未启动"
    fi

    if ss -tlnp 2>/dev/null | grep -q ':80'; then
        print_success "端口80 (Web) 已监听"
    else
        print_error "端口80未监听，Nginx可能未启动"
    fi

    # 检查API
    print_step "验证" "测试API响应..."
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost/api/home 2>/dev/null || echo "000")
    if [ "$HTTP_CODE" = "200" ]; then
        print_success "API响应正常 (HTTP $HTTP_CODE)"
    else
        print_warn "API响应异常 (HTTP $HTTP_CODE)"
    fi

    # 检查前端
    print_step "验证" "测试前端页面..."
    FRONTEND_CODE=$(curl -s -o /dev/null -w "%{http_code}" http://localhost/ 2>/dev/null || echo "000")
    if [ "$FRONTEND_CODE" = "200" ]; then
        print_success "前端页面正常 (HTTP $FRONTEND_CODE)"
    else
        print_warn "前端页面异常 (HTTP $FRONTEND_CODE)"
    fi

    # PM2状态
    echo ""
    $PM2 status
    echo ""
    print_success "部署完成！"
    echo ""
    echo -e "${GREEN}访问地址: http://localhost/${NC}"
    echo -e "${GREEN}API地址:  http://localhost/api/home${NC}"
    echo ""
    echo "常用命令:"
    echo "  查看日志: $PM2 logs $PM2_NAME"
    echo "  重启服务: $PM2 restart $PM2_NAME"
    echo "  停止服务: $PM2 stop $PM2_NAME"
}

# ==========================================
# 主流程
# ==========================================
main() {
    echo ""
    echo -e "${YELLOW}========================================${NC}"
    echo -e "${YELLOW}   $PROJECT_NAME 一键部署脚本 v2.0${NC}"
    echo -e "${YELLOW}========================================${NC}"
    echo ""

    check_env
    sync_frontend
    install_deps
    init_db
    restart_pm2
    save_pm2
    verify
}

# 运行
main "$@"
